/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/index";
exports.ids = ["pages/index"];
exports.modules = {

/***/ "(pages-dir-node)/./components/claim.js":
/*!*****************************!*\
  !*** ./components/claim.js ***!
  \*****************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Claim)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _barrel_optimize_names_Button_Input_antd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! __barrel_optimize__?names=Button,Input!=!antd */ \"(pages-dir-node)/__barrel_optimize__?names=Button,Input!=!./node_modules/antd/lib/index.js\");\n/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ethers */ \"ethers\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([ethers__WEBPACK_IMPORTED_MODULE_1__]);\nethers__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\n\n\nconst daiAddress = \"0x01A01E8B862F10a3907D0fC7f47eBF5d34190341\";\nconst daiAbi = [\n    \"function stakingBalance(uint256 _pid, address _user) view returns(uint256)\",\n    \"function claim(uint256 _pid)\",\n    \"function user(uint256 _pid, address _user) view returns(uint256,uint256,uint256)\"\n];\nfunction Claim({ newProvider, account }) {\n    const [stAmount, setStAmount] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(null);\n    const [finishedMetaNode, setFinishedMetaNode] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(null);\n    const [pendingMetaNode, setPendingMetaNode] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(null);\n    async function getMoney() {\n        if (!newProvider) {\n            alert(\"请先连接钱包\");\n            return;\n        }\n        try {\n            const signer = await newProvider.getSigner();\n            const daiContract = new ethers__WEBPACK_IMPORTED_MODULE_1__.ethers.Contract(daiAddress, daiAbi, signer);\n            const tx = await daiContract.claim(0);\n            const receipt = await tx.wait();\n            console.log(\"交易确认:\", receipt);\n            alert(\"收益领取成功！\");\n        } catch (error) {\n            console.error(\"领取收益失败:\", error);\n            alert(\"领取收益失败，请重试\");\n        }\n    }\n    async function lookUserInfo() {\n        if (!newProvider) {\n            alert(\"请先连接钱包\");\n            return;\n        }\n        try {\n            const signer = await newProvider.getSigner();\n            const daiContract = new ethers__WEBPACK_IMPORTED_MODULE_1__.ethers.Contract(daiAddress, daiAbi, signer);\n            const [stAmountValue, finishedMetaNodeValue, pendingMetaNodeValue] = await daiContract.user(0, account);\n            setStAmount(ethers__WEBPACK_IMPORTED_MODULE_1__.ethers.formatEther(stAmountValue));\n            setFinishedMetaNode(ethers__WEBPACK_IMPORTED_MODULE_1__.ethers.formatEther(finishedMetaNodeValue));\n            setPendingMetaNode(ethers__WEBPACK_IMPORTED_MODULE_1__.ethers.formatEther(pendingMetaNodeValue));\n            console.log(\"质押金额:\", ethers__WEBPACK_IMPORTED_MODULE_1__.ethers.formatEther(stAmountValue));\n            console.log(\"已完成节点:\", ethers__WEBPACK_IMPORTED_MODULE_1__.ethers.formatEther(finishedMetaNodeValue));\n            console.log(\"待处理节点:\", ethers__WEBPACK_IMPORTED_MODULE_1__.ethers.formatEther(pendingMetaNodeValue));\n        } catch (error) {\n            console.error(\"查询用户信息失败:\", error);\n            alert(\"查询用户信息失败，请重试\");\n        }\n    }\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                className: \"mb-4\",\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Input_antd__WEBPACK_IMPORTED_MODULE_3__.Button, {\n                        onClick: getMoney,\n                        className: \"mr-2\",\n                        children: \"领取收益\"\n                    }, void 0, false, {\n                        fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\claim.js\",\n                        lineNumber: 58,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Input_antd__WEBPACK_IMPORTED_MODULE_3__.Button, {\n                        onClick: lookUserInfo,\n                        children: \"查看用户信息\"\n                    }, void 0, false, {\n                        fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\claim.js\",\n                        lineNumber: 59,\n                        columnNumber: 9\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\claim.js\",\n                lineNumber: 57,\n                columnNumber: 7\n            }, this),\n            (stAmount !== null || finishedMetaNode !== null || pendingMetaNode !== null) && /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                className: \"mt-4 p-4 border rounded-lg bg-gray-50\",\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h3\", {\n                        className: \"text-lg font-semibold mb-3\",\n                        children: \"用户信息\"\n                    }, void 0, false, {\n                        fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\claim.js\",\n                        lineNumber: 64,\n                        columnNumber: 11\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                        className: \"space-y-2\",\n                        children: [\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                                className: \"flex justify-between\",\n                                children: [\n                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"span\", {\n                                        className: \"font-medium\",\n                                        children: \"质押金额 (stAmount):\"\n                                    }, void 0, false, {\n                                        fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\claim.js\",\n                                        lineNumber: 67,\n                                        columnNumber: 15\n                                    }, this),\n                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"span\", {\n                                        className: \"text-blue-600\",\n                                        children: stAmount !== null ? `${stAmount} ETH` : '未查询'\n                                    }, void 0, false, {\n                                        fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\claim.js\",\n                                        lineNumber: 68,\n                                        columnNumber: 15\n                                    }, this)\n                                ]\n                            }, void 0, true, {\n                                fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\claim.js\",\n                                lineNumber: 66,\n                                columnNumber: 13\n                            }, this),\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                                className: \"flex justify-between\",\n                                children: [\n                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"span\", {\n                                        className: \"font-medium\",\n                                        children: \"代币 (finishedMetaNode):\"\n                                    }, void 0, false, {\n                                        fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\claim.js\",\n                                        lineNumber: 71,\n                                        columnNumber: 15\n                                    }, this),\n                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"span\", {\n                                        className: \"text-green-600\",\n                                        children: finishedMetaNode !== null ? `${finishedMetaNode} ETH` : '未查询'\n                                    }, void 0, false, {\n                                        fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\claim.js\",\n                                        lineNumber: 72,\n                                        columnNumber: 15\n                                    }, this)\n                                ]\n                            }, void 0, true, {\n                                fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\claim.js\",\n                                lineNumber: 70,\n                                columnNumber: 13\n                            }, this),\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                                className: \"flex justify-between\",\n                                children: [\n                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"span\", {\n                                        className: \"font-medium\",\n                                        children: \"等待处理 (pendingMetaNode):\"\n                                    }, void 0, false, {\n                                        fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\claim.js\",\n                                        lineNumber: 75,\n                                        columnNumber: 15\n                                    }, this),\n                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"span\", {\n                                        className: \"text-orange-600\",\n                                        children: pendingMetaNode !== null ? `${pendingMetaNode} ETH` : '未查询'\n                                    }, void 0, false, {\n                                        fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\claim.js\",\n                                        lineNumber: 76,\n                                        columnNumber: 15\n                                    }, this)\n                                ]\n                            }, void 0, true, {\n                                fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\claim.js\",\n                                lineNumber: 74,\n                                columnNumber: 13\n                            }, this)\n                        ]\n                    }, void 0, true, {\n                        fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\claim.js\",\n                        lineNumber: 65,\n                        columnNumber: 11\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\claim.js\",\n                lineNumber: 63,\n                columnNumber: 9\n            }, this)\n        ]\n    }, void 0, true);\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHBhZ2VzLWRpci1ub2RlKS8uL2NvbXBvbmVudHMvY2xhaW0uanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7QUFBcUM7QUFDTDtBQUNZO0FBQ2hCO0FBQzVCLE1BQU1NLGFBQWE7QUFDbkIsTUFBTUMsU0FBUztJQUNiO0lBQ0E7SUFDQTtDQUNEO0FBQ2MsU0FBVUMsTUFBTSxFQUFFQyxXQUFXLEVBQUVDLE9BQU8sRUFBRTtJQUNyRCxNQUFNLENBQUNDLFVBQVVDLFlBQVksR0FBR1IsK0NBQVFBLENBQUM7SUFDekMsTUFBTSxDQUFDUyxrQkFBa0JDLG9CQUFvQixHQUFHViwrQ0FBUUEsQ0FBQztJQUN6RCxNQUFNLENBQUNXLGlCQUFpQkMsbUJBQW1CLEdBQUdaLCtDQUFRQSxDQUFDO0lBQ3ZELGVBQWVhO1FBQ2IsSUFBSSxDQUFDUixhQUFhO1lBQ2hCUyxNQUFNO1lBQ047UUFDRjtRQUVBLElBQUk7WUFDRixNQUFNQyxTQUFTLE1BQU1WLFlBQVlXLFNBQVM7WUFDMUMsTUFBTUMsY0FBYyxJQUFJbkIsMENBQU1BLENBQUNvQixRQUFRLENBQUNoQixZQUFZQyxRQUFRWTtZQUM1RCxNQUFNSSxLQUFLLE1BQU1GLFlBQVlHLEtBQUssQ0FBQztZQUNuQyxNQUFNQyxVQUFVLE1BQU1GLEdBQUdHLElBQUk7WUFDN0JDLFFBQVFDLEdBQUcsQ0FBQyxTQUFTSDtZQUNyQlAsTUFBTTtRQUNSLEVBQUUsT0FBT1csT0FBTztZQUNkRixRQUFRRSxLQUFLLENBQUMsV0FBV0E7WUFDekJYLE1BQU07UUFDUjtJQUNGO0lBQ0EsZUFBZVk7UUFDYixJQUFJLENBQUNyQixhQUFhO1lBQ2hCUyxNQUFNO1lBQ047UUFDRjtRQUNBLElBQUk7WUFDRixNQUFNQyxTQUFTLE1BQU1WLFlBQVlXLFNBQVM7WUFDMUMsTUFBTUMsY0FBYyxJQUFJbkIsMENBQU1BLENBQUNvQixRQUFRLENBQUNoQixZQUFZQyxRQUFRWTtZQUM1RCxNQUFNLENBQUNZLGVBQWVDLHVCQUF1QkMscUJBQXFCLEdBQUcsTUFBTVosWUFBWWEsSUFBSSxDQUFDLEdBQUd4QjtZQUUvRkUsWUFBWVYsMENBQU1BLENBQUNpQyxXQUFXLENBQUNKO1lBQy9CakIsb0JBQW9CWiwwQ0FBTUEsQ0FBQ2lDLFdBQVcsQ0FBQ0g7WUFDdkNoQixtQkFBbUJkLDBDQUFNQSxDQUFDaUMsV0FBVyxDQUFDRjtZQUV0Q04sUUFBUUMsR0FBRyxDQUFDLFNBQVMxQiwwQ0FBTUEsQ0FBQ2lDLFdBQVcsQ0FBQ0o7WUFDeENKLFFBQVFDLEdBQUcsQ0FBQyxVQUFVMUIsMENBQU1BLENBQUNpQyxXQUFXLENBQUNIO1lBQ3pDTCxRQUFRQyxHQUFHLENBQUMsVUFBVTFCLDBDQUFNQSxDQUFDaUMsV0FBVyxDQUFDRjtRQUMzQyxFQUFFLE9BQU9KLE9BQU87WUFDZEYsUUFBUUUsS0FBSyxDQUFDLGFBQWFBO1lBQzNCWCxNQUFNO1FBQ1I7SUFDRjtJQUNBLHFCQUNFOzswQkFDRSw4REFBQ2tCO2dCQUFJQyxXQUFVOztrQ0FDYiw4REFBQ3JDLDRFQUFNQTt3QkFBQ3NDLFNBQVNyQjt3QkFBVW9CLFdBQVU7a0NBQU87Ozs7OztrQ0FDNUMsOERBQUNyQyw0RUFBTUE7d0JBQUNzQyxTQUFTUjtrQ0FBYzs7Ozs7Ozs7Ozs7O1lBRy9CbkIsQ0FBQUEsYUFBYSxRQUFRRSxxQkFBcUIsUUFBUUUsb0JBQW9CLElBQUcsbUJBQ3pFLDhEQUFDcUI7Z0JBQUlDLFdBQVU7O2tDQUNiLDhEQUFDRTt3QkFBR0YsV0FBVTtrQ0FBNkI7Ozs7OztrQ0FDM0MsOERBQUNEO3dCQUFJQyxXQUFVOzswQ0FDYiw4REFBQ0Q7Z0NBQUlDLFdBQVU7O2tEQUNiLDhEQUFDRzt3Q0FBS0gsV0FBVTtrREFBYzs7Ozs7O2tEQUM5Qiw4REFBQ0c7d0NBQUtILFdBQVU7a0RBQWlCMUIsYUFBYSxPQUFPLEdBQUdBLFNBQVMsSUFBSSxDQUFDLEdBQUc7Ozs7Ozs7Ozs7OzswQ0FFM0UsOERBQUN5QjtnQ0FBSUMsV0FBVTs7a0RBQ2IsOERBQUNHO3dDQUFLSCxXQUFVO2tEQUFjOzs7Ozs7a0RBQzlCLDhEQUFDRzt3Q0FBS0gsV0FBVTtrREFBa0J4QixxQkFBcUIsT0FBTyxHQUFHQSxpQkFBaUIsSUFBSSxDQUFDLEdBQUc7Ozs7Ozs7Ozs7OzswQ0FFNUYsOERBQUN1QjtnQ0FBSUMsV0FBVTs7a0RBQ2IsOERBQUNHO3dDQUFLSCxXQUFVO2tEQUFjOzs7Ozs7a0RBQzlCLDhEQUFDRzt3Q0FBS0gsV0FBVTtrREFBbUJ0QixvQkFBb0IsT0FBTyxHQUFHQSxnQkFBZ0IsSUFBSSxDQUFDLEdBQUc7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBT3ZHIiwic291cmNlcyI6WyJDOlxcbWluZVxcd2Vicm9vdFxcZGVtb1xcaG9tZXdvcmtcXHRlc3QxXFxjb21wb25lbnRzXFxjbGFpbS5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBCdXR0b24sIElucHV0IH0gZnJvbSBcImFudGRcIjtcbmltcG9ydCB7IGV0aGVycyB9IGZyb20gXCJldGhlcnNcIjtcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IFRhYnMgfSBmcm9tIFwiYW50ZFwiO1xuY29uc3QgZGFpQWRkcmVzcyA9IFwiMHgwMUEwMUU4Qjg2MkYxMGEzOTA3RDBmQzdmNDdlQkY1ZDM0MTkwMzQxXCI7XG5jb25zdCBkYWlBYmkgPSBbXG4gIFwiZnVuY3Rpb24gc3Rha2luZ0JhbGFuY2UodWludDI1NiBfcGlkLCBhZGRyZXNzIF91c2VyKSB2aWV3IHJldHVybnModWludDI1NilcIixcbiAgXCJmdW5jdGlvbiBjbGFpbSh1aW50MjU2IF9waWQpXCIsXG4gIFwiZnVuY3Rpb24gdXNlcih1aW50MjU2IF9waWQsIGFkZHJlc3MgX3VzZXIpIHZpZXcgcmV0dXJucyh1aW50MjU2LHVpbnQyNTYsdWludDI1NilcIlxuXTtcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uICBDbGFpbSh7IG5ld1Byb3ZpZGVyLCBhY2NvdW50IH0pIHtcbiAgY29uc3QgW3N0QW1vdW50LCBzZXRTdEFtb3VudF0gPSB1c2VTdGF0ZShudWxsKTtcbiAgY29uc3QgW2ZpbmlzaGVkTWV0YU5vZGUsIHNldEZpbmlzaGVkTWV0YU5vZGVdID0gdXNlU3RhdGUobnVsbCk7XG4gIGNvbnN0IFtwZW5kaW5nTWV0YU5vZGUsIHNldFBlbmRpbmdNZXRhTm9kZV0gPSB1c2VTdGF0ZShudWxsKTtcbiAgYXN5bmMgZnVuY3Rpb24gZ2V0TW9uZXkoKXtcbiAgICBpZiAoIW5ld1Byb3ZpZGVyKSB7XG4gICAgICBhbGVydChcIuivt+WFiOi/nuaOpemSseWMhVwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHNpZ25lciA9IGF3YWl0IG5ld1Byb3ZpZGVyLmdldFNpZ25lcigpO1xuICAgICAgY29uc3QgZGFpQ29udHJhY3QgPSBuZXcgZXRoZXJzLkNvbnRyYWN0KGRhaUFkZHJlc3MsIGRhaUFiaSwgc2lnbmVyKTtcbiAgICAgIGNvbnN0IHR4ID0gYXdhaXQgZGFpQ29udHJhY3QuY2xhaW0oMCk7XG4gICAgICBjb25zdCByZWNlaXB0ID0gYXdhaXQgdHgud2FpdCgpO1xuICAgICAgY29uc29sZS5sb2coXCLkuqTmmJPnoa7orqQ6XCIsIHJlY2VpcHQpO1xuICAgICAgYWxlcnQoXCLmlLbnm4rpooblj5bmiJDlip/vvIFcIik7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCLpooblj5bmlLbnm4rlpLHotKU6XCIsIGVycm9yKTtcbiAgICAgIGFsZXJ0KFwi6aKG5Y+W5pS255uK5aSx6LSl77yM6K+36YeN6K+VXCIpO1xuICAgIH1cbiAgfVxuICBhc3luYyBmdW5jdGlvbiBsb29rVXNlckluZm8oKXtcbiAgICBpZiAoIW5ld1Byb3ZpZGVyKSB7XG4gICAgICBhbGVydChcIuivt+WFiOi/nuaOpemSseWMhVwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHNpZ25lciA9IGF3YWl0IG5ld1Byb3ZpZGVyLmdldFNpZ25lcigpO1xuICAgICAgY29uc3QgZGFpQ29udHJhY3QgPSBuZXcgZXRoZXJzLkNvbnRyYWN0KGRhaUFkZHJlc3MsIGRhaUFiaSwgc2lnbmVyKTtcbiAgICAgIGNvbnN0IFtzdEFtb3VudFZhbHVlLCBmaW5pc2hlZE1ldGFOb2RlVmFsdWUsIHBlbmRpbmdNZXRhTm9kZVZhbHVlXSA9IGF3YWl0IGRhaUNvbnRyYWN0LnVzZXIoMCwgYWNjb3VudCk7XG4gICAgICBcbiAgICAgIHNldFN0QW1vdW50KGV0aGVycy5mb3JtYXRFdGhlcihzdEFtb3VudFZhbHVlKSk7XG4gICAgICBzZXRGaW5pc2hlZE1ldGFOb2RlKGV0aGVycy5mb3JtYXRFdGhlcihmaW5pc2hlZE1ldGFOb2RlVmFsdWUpKTtcbiAgICAgIHNldFBlbmRpbmdNZXRhTm9kZShldGhlcnMuZm9ybWF0RXRoZXIocGVuZGluZ01ldGFOb2RlVmFsdWUpKTtcbiAgICAgIFxuICAgICAgY29uc29sZS5sb2coXCLotKjmirzph5Hpop06XCIsIGV0aGVycy5mb3JtYXRFdGhlcihzdEFtb3VudFZhbHVlKSk7XG4gICAgICBjb25zb2xlLmxvZyhcIuW3suWujOaIkOiKgueCuTpcIiwgZXRoZXJzLmZvcm1hdEV0aGVyKGZpbmlzaGVkTWV0YU5vZGVWYWx1ZSkpO1xuICAgICAgY29uc29sZS5sb2coXCLlvoXlpITnkIboioLngrk6XCIsIGV0aGVycy5mb3JtYXRFdGhlcihwZW5kaW5nTWV0YU5vZGVWYWx1ZSkpO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwi5p+l6K+i55So5oi35L+h5oGv5aSx6LSlOlwiLCBlcnJvcik7XG4gICAgICBhbGVydChcIuafpeivoueUqOaIt+S/oeaBr+Wksei0pe+8jOivt+mHjeivlVwiKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00XCI+XG4gICAgICAgIDxCdXR0b24gb25DbGljaz17Z2V0TW9uZXl9IGNsYXNzTmFtZT1cIm1yLTJcIj7pooblj5bmlLbnm4o8L0J1dHRvbj5cbiAgICAgICAgPEJ1dHRvbiBvbkNsaWNrPXtsb29rVXNlckluZm99Puafpeeci+eUqOaIt+S/oeaBrzwvQnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgICBcbiAgICAgIHsoc3RBbW91bnQgIT09IG51bGwgfHwgZmluaXNoZWRNZXRhTm9kZSAhPT0gbnVsbCB8fCBwZW5kaW5nTWV0YU5vZGUgIT09IG51bGwpICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IHAtNCBib3JkZXIgcm91bmRlZC1sZyBiZy1ncmF5LTUwXCI+XG4gICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCBtYi0zXCI+55So5oi35L+h5oGvPC9oMz5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bVwiPui0qOaKvOmHkeminSAoc3RBbW91bnQpOjwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ibHVlLTYwMFwiPntzdEFtb3VudCAhPT0gbnVsbCA/IGAke3N0QW1vdW50fSBFVEhgIDogJ+acquafpeivoid9PC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtXCI+5Luj5biBIChmaW5pc2hlZE1ldGFOb2RlKTo8L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNjAwXCI+e2ZpbmlzaGVkTWV0YU5vZGUgIT09IG51bGwgPyBgJHtmaW5pc2hlZE1ldGFOb2RlfSBFVEhgIDogJ+acquafpeivoid9PC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtXCI+562J5b6F5aSE55CGIChwZW5kaW5nTWV0YU5vZGUpOjwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1vcmFuZ2UtNjAwXCI+e3BlbmRpbmdNZXRhTm9kZSAhPT0gbnVsbCA/IGAke3BlbmRpbmdNZXRhTm9kZX0gRVRIYCA6ICfmnKrmn6Xor6InfTwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgPC8+XG4gICk7XG59XG4iXSwibmFtZXMiOlsiQnV0dG9uIiwiSW5wdXQiLCJldGhlcnMiLCJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIlRhYnMiLCJkYWlBZGRyZXNzIiwiZGFpQWJpIiwiQ2xhaW0iLCJuZXdQcm92aWRlciIsImFjY291bnQiLCJzdEFtb3VudCIsInNldFN0QW1vdW50IiwiZmluaXNoZWRNZXRhTm9kZSIsInNldEZpbmlzaGVkTWV0YU5vZGUiLCJwZW5kaW5nTWV0YU5vZGUiLCJzZXRQZW5kaW5nTWV0YU5vZGUiLCJnZXRNb25leSIsImFsZXJ0Iiwic2lnbmVyIiwiZ2V0U2lnbmVyIiwiZGFpQ29udHJhY3QiLCJDb250cmFjdCIsInR4IiwiY2xhaW0iLCJyZWNlaXB0Iiwid2FpdCIsImNvbnNvbGUiLCJsb2ciLCJlcnJvciIsImxvb2tVc2VySW5mbyIsInN0QW1vdW50VmFsdWUiLCJmaW5pc2hlZE1ldGFOb2RlVmFsdWUiLCJwZW5kaW5nTWV0YU5vZGVWYWx1ZSIsInVzZXIiLCJmb3JtYXRFdGhlciIsImRpdiIsImNsYXNzTmFtZSIsIm9uQ2xpY2siLCJoMyIsInNwYW4iXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(pages-dir-node)/./components/claim.js\n");

/***/ }),

/***/ "(pages-dir-node)/./components/deposit.js":
/*!*******************************!*\
  !*** ./components/deposit.js ***!
  \*******************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Deposit)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _barrel_optimize_names_Button_Input_Modal_Spin_antd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! __barrel_optimize__?names=Button,Input,Modal,Spin!=!antd */ \"(pages-dir-node)/__barrel_optimize__?names=Button,Input,Modal,Spin!=!./node_modules/antd/lib/index.js\");\n/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ethers */ \"ethers\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([ethers__WEBPACK_IMPORTED_MODULE_1__]);\nethers__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\n\n/**\n * 合约配置\n */ const daiAddress = \"0x01A01E8B862F10a3907D0fC7f47eBF5d34190341\";\nconst daiAbi = [\n    \"function depositETH() payable\",\n    \"function withdrawAmount(uint256 _pid, address _user) view returns(uint256 requestAmount, uint256 pendingWithdrawAmount)\",\n    \"function stakingBalance(uint256 _pid, address _user) view returns(uint256)\"\n];\nfunction Deposit({ newProvider, account }) {\n    const [amount, setAmount] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)();\n    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);\n    async function submit() {\n        if (!amount || amount <= 0) {\n            alert(\"请输入有效的质押金额\");\n            return;\n        }\n        if (!newProvider) {\n            alert(\"请先连接钱包\");\n            return;\n        }\n        try {\n            setLoading(true);\n            const signer = await newProvider.getSigner();\n            const daiContract = new ethers__WEBPACK_IMPORTED_MODULE_1__.ethers.Contract(daiAddress, daiAbi, signer);\n            // 将ETH金额转换为wei\n            const value = ethers__WEBPACK_IMPORTED_MODULE_1__.ethers.parseEther(amount);\n            const tx = await daiContract.depositETH({\n                value: value\n            });\n            console.log(\"交易哈希:\", tx.hash);\n            // 等待交易确认\n            const receipt = await tx.wait();\n            console.log(\"交易确认:\", receipt);\n            alert(\"质押成功！\");\n            // 清空输入框\n            setAmount(\"\");\n        } catch (error) {\n            console.error(\"交易失败:\", error);\n            alert(\"交易失败，请重试\");\n        } finally{\n            setLoading(false);\n        }\n    }\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h3\", {\n                        children: \"质押\"\n                    }, void 0, false, {\n                        fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\deposit.js\",\n                        lineNumber: 55,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Input_Modal_Spin_antd__WEBPACK_IMPORTED_MODULE_3__.Input, {\n                            value: amount,\n                            onChange: (e)=>setAmount(e.target.value),\n                            placeholder: \"请输入质押金额(ETH)\"\n                        }, void 0, false, {\n                            fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\deposit.js\",\n                            lineNumber: 57,\n                            columnNumber: 11\n                        }, this)\n                    }, void 0, false, {\n                        fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\deposit.js\",\n                        lineNumber: 56,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Input_Modal_Spin_antd__WEBPACK_IMPORTED_MODULE_3__.Button, {\n                        onClick: submit,\n                        type: \"primary\",\n                        loading: loading,\n                        children: \"确认质押\"\n                    }, void 0, false, {\n                        fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\deposit.js\",\n                        lineNumber: 63,\n                        columnNumber: 9\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\deposit.js\",\n                lineNumber: 54,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Input_Modal_Spin_antd__WEBPACK_IMPORTED_MODULE_3__.Modal, {\n                open: loading,\n                footer: null,\n                closable: false,\n                centered: true,\n                width: 300,\n                style: {\n                    background: 'rgba(0, 0, 0, 0.5)'\n                },\n                bodyStyle: {\n                    textAlign: 'center',\n                    padding: '24px',\n                    background: 'white',\n                    borderRadius: '8px'\n                },\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                    children: [\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Input_Modal_Spin_antd__WEBPACK_IMPORTED_MODULE_3__.Spin, {\n                            size: \"large\"\n                        }, void 0, false, {\n                            fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\deposit.js\",\n                            lineNumber: 86,\n                            columnNumber: 11\n                        }, this),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                            style: {\n                                marginTop: 16,\n                                fontSize: 16,\n                                color: '#333'\n                            },\n                            children: \"交易处理中，请稍候...\"\n                        }, void 0, false, {\n                            fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\deposit.js\",\n                            lineNumber: 87,\n                            columnNumber: 11\n                        }, this)\n                    ]\n                }, void 0, true, {\n                    fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\deposit.js\",\n                    lineNumber: 85,\n                    columnNumber: 9\n                }, this)\n            }, void 0, false, {\n                fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\deposit.js\",\n                lineNumber: 69,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true);\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHBhZ2VzLWRpci1ub2RlKS8uL2NvbXBvbmVudHMvZGVwb3NpdC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7OztBQUFrRDtBQUNQO0FBQ0M7QUFFNUM7O0NBRUMsR0FDRCxNQUFNUSxhQUFhO0FBQ25CLE1BQU1DLFNBQVM7SUFDYjtJQUNBO0lBQ0E7Q0FDRDtBQUNjLFNBQVNDLFFBQVEsRUFBRUMsV0FBVyxFQUFFQyxPQUFPLEVBQUU7SUFDdEQsTUFBTSxDQUFDQyxRQUFRQyxVQUFVLEdBQUdQLCtDQUFRQTtJQUNwQyxNQUFNLENBQUNRLFNBQVNDLFdBQVcsR0FBR1QsK0NBQVFBLENBQUM7SUFDdkMsZUFBZVU7UUFDYixJQUFJLENBQUNKLFVBQVVBLFVBQVUsR0FBRztZQUMxQkssTUFBTTtZQUNOO1FBQ0Y7UUFFQSxJQUFJLENBQUNQLGFBQWE7WUFDaEJPLE1BQU07WUFDTjtRQUNGO1FBRUEsSUFBSTtZQUNGRixXQUFXO1lBQ1gsTUFBTUcsU0FBUyxNQUFNUixZQUFZUyxTQUFTO1lBQzFDLE1BQU1DLGNBQWMsSUFBSWhCLDBDQUFNQSxDQUFDaUIsUUFBUSxDQUFDZCxZQUFZQyxRQUFRVTtZQUM1RCxlQUFlO1lBQ2YsTUFBTUksUUFBUWxCLDBDQUFNQSxDQUFDbUIsVUFBVSxDQUFDWDtZQUNoQyxNQUFNWSxLQUFLLE1BQU1KLFlBQVlLLFVBQVUsQ0FBQztnQkFBRUgsT0FBT0E7WUFBTTtZQUN2REksUUFBUUMsR0FBRyxDQUFDLFNBQVNILEdBQUdJLElBQUk7WUFFNUIsU0FBUztZQUNULE1BQU1DLFVBQVUsTUFBTUwsR0FBR00sSUFBSTtZQUM3QkosUUFBUUMsR0FBRyxDQUFDLFNBQVNFO1lBQ3JCWixNQUFNO1lBRU4sUUFBUTtZQUNSSixVQUFVO1FBQ1osRUFBRSxPQUFPa0IsT0FBTztZQUNkTCxRQUFRSyxLQUFLLENBQUMsU0FBU0E7WUFDdkJkLE1BQU07UUFDUixTQUFVO1lBQ1JGLFdBQVc7UUFDYjtJQUNGO0lBRUEscUJBQ0U7OzBCQUNFLDhEQUFDaUI7O2tDQUNDLDhEQUFDQztrQ0FBRzs7Ozs7O2tDQUNKLDhEQUFDRDtrQ0FDQyw0RUFBQ2hDLHNGQUFLQTs0QkFDSnNCLE9BQU9WOzRCQUNQc0IsVUFBVSxDQUFDQyxJQUFNdEIsVUFBVXNCLEVBQUVDLE1BQU0sQ0FBQ2QsS0FBSzs0QkFDekNlLGFBQVk7Ozs7Ozs7Ozs7O2tDQUdoQiw4REFBQ3RDLHVGQUFNQTt3QkFBQ3VDLFNBQVN0Qjt3QkFBUXVCLE1BQUs7d0JBQVV6QixTQUFTQTtrQ0FBUzs7Ozs7Ozs7Ozs7OzBCQU01RCw4REFBQ2Isc0ZBQUtBO2dCQUNKdUMsTUFBTTFCO2dCQUNOMkIsUUFBUTtnQkFDUkMsVUFBVTtnQkFDVkMsUUFBUTtnQkFDUkMsT0FBTztnQkFDUEMsT0FBTztvQkFDTEMsWUFBWTtnQkFDZDtnQkFDQUMsV0FBVztvQkFDVEMsV0FBVztvQkFDWEMsU0FBUztvQkFDVEgsWUFBWTtvQkFDWkksY0FBYztnQkFDaEI7MEJBRUEsNEVBQUNsQjs7c0NBQ0MsOERBQUM5QixxRkFBSUE7NEJBQUNpRCxNQUFLOzs7Ozs7c0NBQ1gsOERBQUNuQjs0QkFBSWEsT0FBTztnQ0FBRU8sV0FBVztnQ0FBSUMsVUFBVTtnQ0FBSUMsT0FBTzs0QkFBTztzQ0FBRzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQU90RSIsInNvdXJjZXMiOlsiQzpcXG1pbmVcXHdlYnJvb3RcXGRlbW9cXGhvbWV3b3JrXFx0ZXN0MVxcY29tcG9uZW50c1xcZGVwb3NpdC5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBCdXR0b24sIElucHV0LCBNb2RhbCwgU3BpbiB9IGZyb20gXCJhbnRkXCI7XG5pbXBvcnQgeyBkYXRhU2xpY2UsIGV0aGVycyB9IGZyb20gXCJldGhlcnNcIjtcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcblxuLyoqXG4gKiDlkIjnuqbphY3nva5cbiAqL1xuY29uc3QgZGFpQWRkcmVzcyA9IFwiMHgwMUEwMUU4Qjg2MkYxMGEzOTA3RDBmQzdmNDdlQkY1ZDM0MTkwMzQxXCI7XG5jb25zdCBkYWlBYmkgPSBbXG4gIFwiZnVuY3Rpb24gZGVwb3NpdEVUSCgpIHBheWFibGVcIixcbiAgXCJmdW5jdGlvbiB3aXRoZHJhd0Ftb3VudCh1aW50MjU2IF9waWQsIGFkZHJlc3MgX3VzZXIpIHZpZXcgcmV0dXJucyh1aW50MjU2IHJlcXVlc3RBbW91bnQsIHVpbnQyNTYgcGVuZGluZ1dpdGhkcmF3QW1vdW50KVwiLFxuICBcImZ1bmN0aW9uIHN0YWtpbmdCYWxhbmNlKHVpbnQyNTYgX3BpZCwgYWRkcmVzcyBfdXNlcikgdmlldyByZXR1cm5zKHVpbnQyNTYpXCIsXG5dO1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gRGVwb3NpdCh7IG5ld1Byb3ZpZGVyLCBhY2NvdW50IH0pIHtcbiAgY29uc3QgW2Ftb3VudCwgc2V0QW1vdW50XSA9IHVzZVN0YXRlKCk7XG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgYXN5bmMgZnVuY3Rpb24gc3VibWl0KCkge1xuICAgIGlmICghYW1vdW50IHx8IGFtb3VudCA8PSAwKSB7XG4gICAgICBhbGVydChcIuivt+i+k+WFpeacieaViOeahOi0qOaKvOmHkeminVwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBpZiAoIW5ld1Byb3ZpZGVyKSB7XG4gICAgICBhbGVydChcIuivt+WFiOi/nuaOpemSseWMhVwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICB0cnkge1xuICAgICAgc2V0TG9hZGluZyh0cnVlKTtcbiAgICAgIGNvbnN0IHNpZ25lciA9IGF3YWl0IG5ld1Byb3ZpZGVyLmdldFNpZ25lcigpO1xuICAgICAgY29uc3QgZGFpQ29udHJhY3QgPSBuZXcgZXRoZXJzLkNvbnRyYWN0KGRhaUFkZHJlc3MsIGRhaUFiaSwgc2lnbmVyKTtcbiAgICAgIC8vIOWwhkVUSOmHkeminei9rOaNouS4undlaVxuICAgICAgY29uc3QgdmFsdWUgPSBldGhlcnMucGFyc2VFdGhlcihhbW91bnQpO1xuICAgICAgY29uc3QgdHggPSBhd2FpdCBkYWlDb250cmFjdC5kZXBvc2l0RVRIKHsgdmFsdWU6IHZhbHVlIH0pO1xuICAgICAgY29uc29sZS5sb2coXCLkuqTmmJPlk4jluIw6XCIsIHR4Lmhhc2gpO1xuXG4gICAgICAvLyDnrYnlvoXkuqTmmJPnoa7orqRcbiAgICAgIGNvbnN0IHJlY2VpcHQgPSBhd2FpdCB0eC53YWl0KCk7XG4gICAgICBjb25zb2xlLmxvZyhcIuS6pOaYk+ehruiupDpcIiwgcmVjZWlwdCk7XG4gICAgICBhbGVydChcIui0qOaKvOaIkOWKn++8gVwiKTtcblxuICAgICAgLy8g5riF56m66L6T5YWl5qGGXG4gICAgICBzZXRBbW91bnQoXCJcIik7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCLkuqTmmJPlpLHotKU6XCIsIGVycm9yKTtcbiAgICAgIGFsZXJ0KFwi5Lqk5piT5aSx6LSl77yM6K+36YeN6K+VXCIpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8ZGl2PlxuICAgICAgICA8aDM+6LSo5oq8PC9oMz5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8SW5wdXRcbiAgICAgICAgICAgIHZhbHVlPXthbW91bnR9XG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEFtb3VudChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cIuivt+i+k+WFpei0qOaKvOmHkeminShFVEgpXCJcbiAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPEJ1dHRvbiBvbkNsaWNrPXtzdWJtaXR9IHR5cGU9XCJwcmltYXJ5XCIgbG9hZGluZz17bG9hZGluZ30+XG4gICAgICAgICAg56Gu6K6k6LSo5oq8XG4gICAgICAgIDwvQnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgICBcbiAgICAgIHsvKiDlsYXkuK1sb2FkaW5n5qih5oCB5qGGICovfVxuICAgICAgPE1vZGFsXG4gICAgICAgIG9wZW49e2xvYWRpbmd9XG4gICAgICAgIGZvb3Rlcj17bnVsbH1cbiAgICAgICAgY2xvc2FibGU9e2ZhbHNlfVxuICAgICAgICBjZW50ZXJlZFxuICAgICAgICB3aWR0aD17MzAwfVxuICAgICAgICBzdHlsZT17e1xuICAgICAgICAgIGJhY2tncm91bmQ6ICdyZ2JhKDAsIDAsIDAsIDAuNSknLFxuICAgICAgICB9fVxuICAgICAgICBib2R5U3R5bGU9e3tcbiAgICAgICAgICB0ZXh0QWxpZ246ICdjZW50ZXInLFxuICAgICAgICAgIHBhZGRpbmc6ICcyNHB4JyxcbiAgICAgICAgICBiYWNrZ3JvdW5kOiAnd2hpdGUnLFxuICAgICAgICAgIGJvcmRlclJhZGl1czogJzhweCcsXG4gICAgICAgIH19XG4gICAgICA+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPFNwaW4gc2l6ZT1cImxhcmdlXCIgLz5cbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IG1hcmdpblRvcDogMTYsIGZvbnRTaXplOiAxNiwgY29sb3I6ICcjMzMzJyB9fT5cbiAgICAgICAgICAgIOS6pOaYk+WkhOeQhuS4re+8jOivt+eojeWAmS4uLlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvTW9kYWw+XG4gICAgPC8+XG4gICk7XG59XG4iXSwibmFtZXMiOlsiQnV0dG9uIiwiSW5wdXQiLCJNb2RhbCIsIlNwaW4iLCJkYXRhU2xpY2UiLCJldGhlcnMiLCJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsImRhaUFkZHJlc3MiLCJkYWlBYmkiLCJEZXBvc2l0IiwibmV3UHJvdmlkZXIiLCJhY2NvdW50IiwiYW1vdW50Iiwic2V0QW1vdW50IiwibG9hZGluZyIsInNldExvYWRpbmciLCJzdWJtaXQiLCJhbGVydCIsInNpZ25lciIsImdldFNpZ25lciIsImRhaUNvbnRyYWN0IiwiQ29udHJhY3QiLCJ2YWx1ZSIsInBhcnNlRXRoZXIiLCJ0eCIsImRlcG9zaXRFVEgiLCJjb25zb2xlIiwibG9nIiwiaGFzaCIsInJlY2VpcHQiLCJ3YWl0IiwiZXJyb3IiLCJkaXYiLCJoMyIsIm9uQ2hhbmdlIiwiZSIsInRhcmdldCIsInBsYWNlaG9sZGVyIiwib25DbGljayIsInR5cGUiLCJvcGVuIiwiZm9vdGVyIiwiY2xvc2FibGUiLCJjZW50ZXJlZCIsIndpZHRoIiwic3R5bGUiLCJiYWNrZ3JvdW5kIiwiYm9keVN0eWxlIiwidGV4dEFsaWduIiwicGFkZGluZyIsImJvcmRlclJhZGl1cyIsInNpemUiLCJtYXJnaW5Ub3AiLCJmb250U2l6ZSIsImNvbG9yIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(pages-dir-node)/./components/deposit.js\n");

/***/ }),

/***/ "(pages-dir-node)/./components/withdraw.js":
/*!********************************!*\
  !*** ./components/withdraw.js ***!
  \********************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Withdraw)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _barrel_optimize_names_Button_Input_antd__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! __barrel_optimize__?names=Button,Input!=!antd */ \"(pages-dir-node)/__barrel_optimize__?names=Button,Input!=!./node_modules/antd/lib/index.js\");\n/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ethers */ \"ethers\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _barrel_optimize_names_Card_antd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! __barrel_optimize__?names=Card!=!antd */ \"(pages-dir-node)/__barrel_optimize__?names=Card!=!./node_modules/antd/lib/index.js\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([ethers__WEBPACK_IMPORTED_MODULE_1__]);\nethers__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\n\n\nconst daiAddress = \"0x01A01E8B862F10a3907D0fC7f47eBF5d34190341\";\nconst daiAbi = [\n    \"function depositETH() payable\",\n    \"function withdrawAmount(uint256 _pid, address _user) view returns(uint256 requestAmount, uint256 pendingWithdrawAmount)\",\n    \"function stakingBalance(uint256 _pid, address _user) view returns(uint256)\",\n    \"function unstake(uint256 _pid, uint256 _amount)\",\n    \"function withdraw(uint256 _pid)\"\n];\nlet signer;\nlet daiContract;\nlet unstakeAmount = 0;\nfunction Withdraw({ newProvider, account }) {\n    const [userInfo, setUserInfo] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({});\n    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)({\n        \"Withdraw.useEffect\": ()=>{\n            if (newProvider && account) {\n                ({\n                    \"Withdraw.useEffect\": async ()=>{\n                        signer = await newProvider.getSigner();\n                        daiContract = new ethers__WEBPACK_IMPORTED_MODULE_1__.ethers.Contract(daiAddress, daiAbi, signer);\n                        queryStakingBalance();\n                    }\n                })[\"Withdraw.useEffect\"]();\n            }\n        }\n    }[\"Withdraw.useEffect\"], [\n        newProvider,\n        account\n    ]);\n    /**\r\n   * 查询质押 取款 冻结余额\r\n   * @returns \r\n   */ async function queryStakingBalance() {\n        if (!newProvider) {\n            alert(\"请先连接钱包\");\n            return;\n        }\n        const stakingBalance = await daiContract.stakingBalance(0, account);\n        const [requestAmount, pendingWithdrawAmount] = await daiContract.withdrawAmount(0, account);\n        let total = requestAmount;\n        let ava = pendingWithdrawAmount;\n        setUserInfo({\n            stakingBalance: ethers__WEBPACK_IMPORTED_MODULE_1__.ethers.formatEther(stakingBalance),\n            requestAmount: ethers__WEBPACK_IMPORTED_MODULE_1__.ethers.formatEther(ava),\n            pendingWithdrawAmount: ethers__WEBPACK_IMPORTED_MODULE_1__.ethers.formatEther(total - ava)\n        });\n        console.log(\"质押余额:\", ethers__WEBPACK_IMPORTED_MODULE_1__.ethers.formatEther(stakingBalance));\n        console.log(\"取款金额:\", ethers__WEBPACK_IMPORTED_MODULE_1__.ethers.formatEther(requestAmount));\n        console.log(\"冻结金额:\", ethers__WEBPACK_IMPORTED_MODULE_1__.ethers.formatEther(pendingWithdrawAmount));\n    }\n    /**\r\n   * 解除质押\r\n   * @returns \r\n   */ async function unstake() {\n        if (!newProvider) {\n            alert(\"请先连接钱包\");\n            return;\n        }\n        // Convert the string amount to wei (BigInt)\n        const amountInWei = ethers__WEBPACK_IMPORTED_MODULE_1__.ethers.parseEther(unstakeAmount.toString());\n        const tx = await daiContract.unstake(0, amountInWei);\n        const receipt = await tx.wait();\n        console.log(\"交易确认:\", receipt);\n        alert(\"解除质押成功\");\n        queryStakingBalance();\n    }\n    /**\r\n   * 提款\r\n   * @returns \r\n   */ async function withdraw() {\n        if (!newProvider) {\n            alert(\"请先连接钱包\");\n            return;\n        }\n        await daiContract.withdraw(0);\n        alert(\"提款成功\");\n        queryStakingBalance();\n    }\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                className: \"flex gap-[20px]\",\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Card_antd__WEBPACK_IMPORTED_MODULE_3__.Card, {\n                        style: {\n                            width: 300\n                        },\n                        children: [\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                                children: \"质押余额:\"\n                            }, void 0, false, {\n                                fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\withdraw.js\",\n                                lineNumber: 85,\n                                columnNumber: 11\n                            }, this),\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                                children: [\n                                    userInfo.stakingBalance,\n                                    \" ETH\"\n                                ]\n                            }, void 0, true, {\n                                fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\withdraw.js\",\n                                lineNumber: 86,\n                                columnNumber: 11\n                            }, this)\n                        ]\n                    }, void 0, true, {\n                        fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\withdraw.js\",\n                        lineNumber: 84,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Card_antd__WEBPACK_IMPORTED_MODULE_3__.Card, {\n                        style: {\n                            width: 300\n                        },\n                        children: [\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                                children: \"取款金额\"\n                            }, void 0, false, {\n                                fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\withdraw.js\",\n                                lineNumber: 89,\n                                columnNumber: 11\n                            }, this),\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                                children: [\n                                    userInfo.requestAmount,\n                                    \" ETH\"\n                                ]\n                            }, void 0, true, {\n                                fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\withdraw.js\",\n                                lineNumber: 90,\n                                columnNumber: 11\n                            }, this)\n                        ]\n                    }, void 0, true, {\n                        fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\withdraw.js\",\n                        lineNumber: 88,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Card_antd__WEBPACK_IMPORTED_MODULE_3__.Card, {\n                        style: {\n                            width: 300\n                        },\n                        children: [\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                                children: \"冻结金额:\"\n                            }, void 0, false, {\n                                fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\withdraw.js\",\n                                lineNumber: 93,\n                                columnNumber: 11\n                            }, this),\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                                children: [\n                                    userInfo.pendingWithdrawAmount,\n                                    \" ETH\"\n                                ]\n                            }, void 0, true, {\n                                fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\withdraw.js\",\n                                lineNumber: 94,\n                                columnNumber: 11\n                            }, this)\n                        ]\n                    }, void 0, true, {\n                        fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\withdraw.js\",\n                        lineNumber: 92,\n                        columnNumber: 9\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\withdraw.js\",\n                lineNumber: 83,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                        className: \"mt-[10px]\",\n                        children: \"解除质押\"\n                    }, void 0, false, {\n                        fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\withdraw.js\",\n                        lineNumber: 99,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                        className: \"flex py-[10px]\",\n                        children: [\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Input_antd__WEBPACK_IMPORTED_MODULE_4__.Input, {\n                                onChange: (e)=>unstakeAmount = e.target.value,\n                                placeholder: \"请输入解除质押金额\"\n                            }, void 0, false, {\n                                fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\withdraw.js\",\n                                lineNumber: 101,\n                                columnNumber: 11\n                            }, this),\n                            \"\\xa0\\xa0\",\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Input_antd__WEBPACK_IMPORTED_MODULE_4__.Button, {\n                                onClick: unstake,\n                                type: \"primary\",\n                                children: \"确定\"\n                            }, void 0, false, {\n                                fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\withdraw.js\",\n                                lineNumber: 103,\n                                columnNumber: 11\n                            }, this)\n                        ]\n                    }, void 0, true, {\n                        fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\withdraw.js\",\n                        lineNumber: 100,\n                        columnNumber: 9\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\withdraw.js\",\n                lineNumber: 98,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                        className: \"mt-[10px]\",\n                        children: \"取款\"\n                    }, void 0, false, {\n                        fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\withdraw.js\",\n                        lineNumber: 108,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                        className: \"flex py-[10px] items-center\",\n                        children: [\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                                children: [\n                                    userInfo.requestAmount,\n                                    \" ETH\\xa0\\xa0\"\n                                ]\n                            }, void 0, true, {\n                                fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\withdraw.js\",\n                                lineNumber: 110,\n                                columnNumber: 11\n                            }, this),\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Input_antd__WEBPACK_IMPORTED_MODULE_4__.Button, {\n                                onClick: withdraw,\n                                type: \"primary\",\n                                children: \"确定\"\n                            }, void 0, false, {\n                                fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\withdraw.js\",\n                                lineNumber: 111,\n                                columnNumber: 11\n                            }, this)\n                        ]\n                    }, void 0, true, {\n                        fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\withdraw.js\",\n                        lineNumber: 109,\n                        columnNumber: 9\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\components\\\\withdraw.js\",\n                lineNumber: 107,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true);\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHBhZ2VzLWRpci1ub2RlKS8uL2NvbXBvbmVudHMvd2l0aGRyYXcuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7O0FBQXFDO0FBQ0w7QUFDaUI7QUFDckI7QUFDNUIsTUFBTU8sYUFBYTtBQUNuQixNQUFNQyxTQUFTO0lBQ2I7SUFDQTtJQUNBO0lBQ0E7SUFDQTtDQUNEO0FBQ0QsSUFBSUM7QUFDSixJQUFJQztBQUNKLElBQUlDLGdCQUFnQjtBQUNMLFNBQVNDLFNBQVMsRUFBRUMsV0FBVyxFQUFFQyxPQUFPLEVBQUU7SUFDdkQsTUFBTSxDQUFDQyxVQUFVQyxZQUFZLEdBQUdYLCtDQUFRQSxDQUFDLENBQUM7SUFDMUNELGdEQUFTQTs4QkFBQztZQUNSLElBQUlTLGVBQWVDLFNBQVM7Z0JBQzFCOzBDQUFDO3dCQUNDTCxTQUFTLE1BQU1JLFlBQVlJLFNBQVM7d0JBQ3BDUCxjQUFjLElBQUlSLDBDQUFNQSxDQUFDZ0IsUUFBUSxDQUFDWCxZQUFZQyxRQUFRQzt3QkFDdERVO29CQUNGOztZQUNGO1FBQ0Y7NkJBQUc7UUFBQ047UUFBYUM7S0FBUTtJQUN6Qjs7O0dBR0MsR0FDRCxlQUFlSztRQUNiLElBQUksQ0FBQ04sYUFBYTtZQUNoQk8sTUFBTTtZQUNOO1FBQ0Y7UUFFQSxNQUFNQyxpQkFBaUIsTUFBTVgsWUFBWVcsY0FBYyxDQUFDLEdBQUdQO1FBQzNELE1BQU0sQ0FBQ1EsZUFBZUMsc0JBQXNCLEdBQUUsTUFBTWIsWUFBWWMsY0FBYyxDQUFDLEdBQUdWO1FBQ2xGLElBQUlXLFFBQU1IO1FBQ1YsSUFBSUksTUFBSUg7UUFDUlAsWUFBWTtZQUNWSyxnQkFBZ0JuQiwwQ0FBTUEsQ0FBQ3lCLFdBQVcsQ0FBQ047WUFDbkNDLGVBQWVwQiwwQ0FBTUEsQ0FBQ3lCLFdBQVcsQ0FBQ0Q7WUFDbENILHVCQUF1QnJCLDBDQUFNQSxDQUFDeUIsV0FBVyxDQUFDRixRQUFRQztRQUVwRDtRQUNBRSxRQUFRQyxHQUFHLENBQUMsU0FBUzNCLDBDQUFNQSxDQUFDeUIsV0FBVyxDQUFDTjtRQUN4Q08sUUFBUUMsR0FBRyxDQUFDLFNBQVMzQiwwQ0FBTUEsQ0FBQ3lCLFdBQVcsQ0FBQ0w7UUFDeENNLFFBQVFDLEdBQUcsQ0FBQyxTQUFTM0IsMENBQU1BLENBQUN5QixXQUFXLENBQUNKO0lBQzFDO0lBQ0E7OztHQUdDLEdBQ0QsZUFBZU87UUFDYixJQUFJLENBQUNqQixhQUFhO1lBQ2hCTyxNQUFNO1lBQ047UUFDRjtRQUNBLDRDQUE0QztRQUM1QyxNQUFNVyxjQUFjN0IsMENBQU1BLENBQUM4QixVQUFVLENBQUNyQixjQUFjc0IsUUFBUTtRQUM1RCxNQUFNQyxLQUFLLE1BQU14QixZQUFZb0IsT0FBTyxDQUFDLEdBQUdDO1FBQ3hDLE1BQU1JLFVBQVUsTUFBTUQsR0FBR0UsSUFBSTtRQUM3QlIsUUFBUUMsR0FBRyxDQUFDLFNBQVNNO1FBQ3JCZixNQUFNO1FBQ05EO0lBQ0Y7SUFDQTs7O0dBR0MsR0FDRCxlQUFla0I7UUFDYixJQUFJLENBQUN4QixhQUFhO1lBQ2hCTyxNQUFNO1lBQ047UUFDRjtRQUNBLE1BQU1WLFlBQVkyQixRQUFRLENBQUM7UUFDM0JqQixNQUFNO1FBQ05EO0lBQ0Y7SUFDQSxxQkFDRTs7MEJBQ0UsOERBQUNtQjtnQkFBSUMsV0FBVTs7a0NBQ2IsOERBQUNqQyxrRUFBSUE7d0JBQUNrQyxPQUFPOzRCQUFFQyxPQUFPO3dCQUFJOzswQ0FDeEIsOERBQUNDOzBDQUFFOzs7Ozs7MENBQ0gsOERBQUNBOztvQ0FBRzNCLFNBQVNNLGNBQWM7b0NBQUM7Ozs7Ozs7Ozs7Ozs7a0NBRTlCLDhEQUFDZixrRUFBSUE7d0JBQUNrQyxPQUFPOzRCQUFFQyxPQUFPO3dCQUFJOzswQ0FDeEIsOERBQUNDOzBDQUFFOzs7Ozs7MENBQ0gsOERBQUNBOztvQ0FBRzNCLFNBQVNPLGFBQWE7b0NBQUM7Ozs7Ozs7Ozs7Ozs7a0NBRTdCLDhEQUFDaEIsa0VBQUlBO3dCQUFDa0MsT0FBTzs0QkFBRUMsT0FBTzt3QkFBSTs7MENBQ3hCLDhEQUFDQzswQ0FBRTs7Ozs7OzBDQUNILDhEQUFDQTs7b0NBQUczQixTQUFTUSxxQkFBcUI7b0NBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7MEJBSXZDLDhEQUFDZTs7a0NBQ0MsOERBQUNJO3dCQUFFSCxXQUFVO2tDQUFZOzs7Ozs7a0NBQ3pCLDhEQUFDRDt3QkFBSUMsV0FBVTs7MENBQ2IsOERBQUN0QywyRUFBS0E7Z0NBQUMwQyxVQUFVLENBQUNDLElBQU1qQyxnQkFBZ0JpQyxFQUFFQyxNQUFNLENBQUNDLEtBQUs7Z0NBQUVDLGFBQVk7Ozs7Ozs0QkFBYzswQ0FFbEYsOERBQUMvQyw0RUFBTUE7Z0NBQUNnRCxTQUFTbEI7Z0NBQVNtQixNQUFLOzBDQUFVOzs7Ozs7Ozs7Ozs7Ozs7Ozs7MEJBSTdDLDhEQUFDWDs7a0NBQ0MsOERBQUNJO3dCQUFFSCxXQUFVO2tDQUFZOzs7Ozs7a0NBQ3pCLDhEQUFDRDt3QkFBSUMsV0FBVTs7MENBQ2IsOERBQUNHOztvQ0FBRzNCLFNBQVNPLGFBQWE7b0NBQUM7Ozs7Ozs7MENBQzNCLDhEQUFDdEIsNEVBQU1BO2dDQUFDZ0QsU0FBU1g7Z0NBQVVZLE1BQUs7MENBQVU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBS3BEIiwic291cmNlcyI6WyJDOlxcbWluZVxcd2Vicm9vdFxcZGVtb1xcaG9tZXdvcmtcXHRlc3QxXFxjb21wb25lbnRzXFx3aXRoZHJhdy5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBCdXR0b24sIElucHV0IH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IHsgZXRoZXJzIH0gZnJvbSBcImV0aGVyc1wiO1xyXG5pbXBvcnQgeyB1c2UsIHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgQ2FyZCB9IGZyb20gXCJhbnRkXCI7XHJcbmNvbnN0IGRhaUFkZHJlc3MgPSBcIjB4MDFBMDFFOEI4NjJGMTBhMzkwN0QwZkM3ZjQ3ZUJGNWQzNDE5MDM0MVwiO1xyXG5jb25zdCBkYWlBYmkgPSBbXHJcbiAgXCJmdW5jdGlvbiBkZXBvc2l0RVRIKCkgcGF5YWJsZVwiLFxyXG4gIFwiZnVuY3Rpb24gd2l0aGRyYXdBbW91bnQodWludDI1NiBfcGlkLCBhZGRyZXNzIF91c2VyKSB2aWV3IHJldHVybnModWludDI1NiByZXF1ZXN0QW1vdW50LCB1aW50MjU2IHBlbmRpbmdXaXRoZHJhd0Ftb3VudClcIixcclxuICBcImZ1bmN0aW9uIHN0YWtpbmdCYWxhbmNlKHVpbnQyNTYgX3BpZCwgYWRkcmVzcyBfdXNlcikgdmlldyByZXR1cm5zKHVpbnQyNTYpXCIsXHJcbiAgXCJmdW5jdGlvbiB1bnN0YWtlKHVpbnQyNTYgX3BpZCwgdWludDI1NiBfYW1vdW50KVwiLFxyXG4gIFwiZnVuY3Rpb24gd2l0aGRyYXcodWludDI1NiBfcGlkKVwiXHJcbl07XHJcbmxldCBzaWduZXI7XHJcbmxldCBkYWlDb250cmFjdDtcclxubGV0IHVuc3Rha2VBbW91bnQgPSAwO1xyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBXaXRoZHJhdyh7IG5ld1Byb3ZpZGVyLCBhY2NvdW50IH0pIHtcclxuICBjb25zdCBbdXNlckluZm8sIHNldFVzZXJJbmZvXSA9IHVzZVN0YXRlKHt9KTtcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKG5ld1Byb3ZpZGVyICYmIGFjY291bnQpIHtcclxuICAgICAgKGFzeW5jICgpID0+IHtcclxuICAgICAgICBzaWduZXIgPSBhd2FpdCBuZXdQcm92aWRlci5nZXRTaWduZXIoKTtcclxuICAgICAgICBkYWlDb250cmFjdCA9IG5ldyBldGhlcnMuQ29udHJhY3QoZGFpQWRkcmVzcywgZGFpQWJpLCBzaWduZXIpO1xyXG4gICAgICAgIHF1ZXJ5U3Rha2luZ0JhbGFuY2UoKTtcclxuICAgICAgfSkoKTtcclxuICAgIH1cclxuICB9LCBbbmV3UHJvdmlkZXIsIGFjY291bnRdKTtcclxuICAvKipcclxuICAgKiDmn6Xor6LotKjmirwg5Y+W5qy+IOWGu+e7k+S9meminVxyXG4gICAqIEByZXR1cm5zIFxyXG4gICAqL1xyXG4gIGFzeW5jIGZ1bmN0aW9uIHF1ZXJ5U3Rha2luZ0JhbGFuY2UoKSB7XHJcbiAgICBpZiAoIW5ld1Byb3ZpZGVyKSB7XHJcbiAgICAgIGFsZXJ0KFwi6K+35YWI6L+e5o6l6ZKx5YyFXCIpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3Qgc3Rha2luZ0JhbGFuY2UgPSBhd2FpdCBkYWlDb250cmFjdC5zdGFraW5nQmFsYW5jZSgwLCBhY2NvdW50KTtcclxuICAgIGNvbnN0IFtyZXF1ZXN0QW1vdW50LCBwZW5kaW5nV2l0aGRyYXdBbW91bnRdID1hd2FpdCBkYWlDb250cmFjdC53aXRoZHJhd0Ftb3VudCgwLCBhY2NvdW50KTtcclxuICAgIGxldCB0b3RhbD1yZXF1ZXN0QW1vdW50O1xyXG4gICAgbGV0IGF2YT1wZW5kaW5nV2l0aGRyYXdBbW91bnQ7XHJcbiAgICBzZXRVc2VySW5mbyh7XHJcbiAgICAgIHN0YWtpbmdCYWxhbmNlOiBldGhlcnMuZm9ybWF0RXRoZXIoc3Rha2luZ0JhbGFuY2UpLFxyXG4gICAgICByZXF1ZXN0QW1vdW50OiBldGhlcnMuZm9ybWF0RXRoZXIoYXZhKSxcclxuICAgICAgcGVuZGluZ1dpdGhkcmF3QW1vdW50OiBldGhlcnMuZm9ybWF0RXRoZXIodG90YWwgLSBhdmEpLFxyXG4gICAgXHJcbiAgICB9KTtcclxuICAgIGNvbnNvbGUubG9nKFwi6LSo5oq85L2Z6aKdOlwiLCBldGhlcnMuZm9ybWF0RXRoZXIoc3Rha2luZ0JhbGFuY2UpKTtcclxuICAgIGNvbnNvbGUubG9nKFwi5Y+W5qy+6YeR6aKdOlwiLCBldGhlcnMuZm9ybWF0RXRoZXIocmVxdWVzdEFtb3VudCkpO1xyXG4gICAgY29uc29sZS5sb2coXCLlhrvnu5Pph5Hpop06XCIsIGV0aGVycy5mb3JtYXRFdGhlcihwZW5kaW5nV2l0aGRyYXdBbW91bnQpKTtcclxuICB9XHJcbiAgLyoqXHJcbiAgICog6Kej6Zmk6LSo5oq8XHJcbiAgICogQHJldHVybnMgXHJcbiAgICovXHJcbiAgYXN5bmMgZnVuY3Rpb24gdW5zdGFrZSgpIHtcclxuICAgIGlmICghbmV3UHJvdmlkZXIpIHtcclxuICAgICAgYWxlcnQoXCLor7flhYjov57mjqXpkrHljIVcIik7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIC8vIENvbnZlcnQgdGhlIHN0cmluZyBhbW91bnQgdG8gd2VpIChCaWdJbnQpXHJcbiAgICBjb25zdCBhbW91bnRJbldlaSA9IGV0aGVycy5wYXJzZUV0aGVyKHVuc3Rha2VBbW91bnQudG9TdHJpbmcoKSk7XHJcbiAgICBjb25zdCB0eCAgPWF3YWl0IGRhaUNvbnRyYWN0LnVuc3Rha2UoMCwgYW1vdW50SW5XZWkpO1xyXG4gICAgY29uc3QgcmVjZWlwdCA9IGF3YWl0IHR4LndhaXQoKTtcclxuICAgIGNvbnNvbGUubG9nKFwi5Lqk5piT56Gu6K6kOlwiLCByZWNlaXB0KTtcclxuICAgIGFsZXJ0KFwi6Kej6Zmk6LSo5oq85oiQ5YqfXCIpO1xyXG4gICAgcXVlcnlTdGFraW5nQmFsYW5jZSgpO1xyXG4gIH1cclxuICAvKipcclxuICAgKiDmj5DmrL5cclxuICAgKiBAcmV0dXJucyBcclxuICAgKi9cclxuICBhc3luYyBmdW5jdGlvbiB3aXRoZHJhdygpIHtcclxuICAgIGlmICghbmV3UHJvdmlkZXIpIHtcclxuICAgICAgYWxlcnQoXCLor7flhYjov57mjqXpkrHljIVcIik7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIGF3YWl0IGRhaUNvbnRyYWN0LndpdGhkcmF3KDApO1xyXG4gICAgYWxlcnQoXCLmj5DmrL7miJDlip9cIik7XHJcbiAgICBxdWVyeVN0YWtpbmdCYWxhbmNlKCk7XHJcbiAgfVxyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLVsyMHB4XVwiPlxyXG4gICAgICAgIDxDYXJkIHN0eWxlPXt7IHdpZHRoOiAzMDAgfX0+XHJcbiAgICAgICAgICA8cD7otKjmirzkvZnpop06PC9wPlxyXG4gICAgICAgICAgPHA+e3VzZXJJbmZvLnN0YWtpbmdCYWxhbmNlfSBFVEg8L3A+XHJcbiAgICAgICAgPC9DYXJkPlxyXG4gICAgICAgIDxDYXJkIHN0eWxlPXt7IHdpZHRoOiAzMDAgfX0+XHJcbiAgICAgICAgICA8cD7lj5bmrL7ph5Hpop08L3A+XHJcbiAgICAgICAgICA8cD57dXNlckluZm8ucmVxdWVzdEFtb3VudH0gRVRIPC9wPlxyXG4gICAgICAgIDwvQ2FyZD5cclxuICAgICAgICA8Q2FyZCBzdHlsZT17eyB3aWR0aDogMzAwIH19PlxyXG4gICAgICAgICAgPHA+5Ya757uT6YeR6aKdOjwvcD5cclxuICAgICAgICAgIDxwPnt1c2VySW5mby5wZW5kaW5nV2l0aGRyYXdBbW91bnR9IEVUSDwvcD5cclxuICAgICAgICA8L0NhcmQ+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPGRpdj5cclxuICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC1bMTBweF1cIj7op6PpmaTotKjmirw8L3A+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHB5LVsxMHB4XVwiPlxyXG4gICAgICAgICAgPElucHV0IG9uQ2hhbmdlPXsoZSkgPT4gdW5zdGFrZUFtb3VudCA9IGUudGFyZ2V0LnZhbHVlfSBwbGFjZWhvbGRlcj1cIuivt+i+k+WFpeino+mZpOi0qOaKvOmHkeminVwiIC8+XHJcbiAgICAgICAgICAmbmJzcDsmbmJzcDtcclxuICAgICAgICAgIDxCdXR0b24gb25DbGljaz17dW5zdGFrZX0gdHlwZT1cInByaW1hcnlcIj7noa7lrpo8L0J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8ZGl2PlxyXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LVsxMHB4XVwiPuWPluasvjwvcD5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggcHktWzEwcHhdIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgPHA+e3VzZXJJbmZvLnJlcXVlc3RBbW91bnR9IEVUSCZuYnNwOyZuYnNwOzwvcD5cclxuICAgICAgICAgIDxCdXR0b24gb25DbGljaz17d2l0aGRyYXd9IHR5cGU9XCJwcmltYXJ5XCI+56Gu5a6aPC9CdXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC8+XHJcbiAgKTtcclxufVxyXG4iXSwibmFtZXMiOlsiQnV0dG9uIiwiSW5wdXQiLCJldGhlcnMiLCJ1c2UiLCJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIkNhcmQiLCJkYWlBZGRyZXNzIiwiZGFpQWJpIiwic2lnbmVyIiwiZGFpQ29udHJhY3QiLCJ1bnN0YWtlQW1vdW50IiwiV2l0aGRyYXciLCJuZXdQcm92aWRlciIsImFjY291bnQiLCJ1c2VySW5mbyIsInNldFVzZXJJbmZvIiwiZ2V0U2lnbmVyIiwiQ29udHJhY3QiLCJxdWVyeVN0YWtpbmdCYWxhbmNlIiwiYWxlcnQiLCJzdGFraW5nQmFsYW5jZSIsInJlcXVlc3RBbW91bnQiLCJwZW5kaW5nV2l0aGRyYXdBbW91bnQiLCJ3aXRoZHJhd0Ftb3VudCIsInRvdGFsIiwiYXZhIiwiZm9ybWF0RXRoZXIiLCJjb25zb2xlIiwibG9nIiwidW5zdGFrZSIsImFtb3VudEluV2VpIiwicGFyc2VFdGhlciIsInRvU3RyaW5nIiwidHgiLCJyZWNlaXB0Iiwid2FpdCIsIndpdGhkcmF3IiwiZGl2IiwiY2xhc3NOYW1lIiwic3R5bGUiLCJ3aWR0aCIsInAiLCJvbkNoYW5nZSIsImUiLCJ0YXJnZXQiLCJ2YWx1ZSIsInBsYWNlaG9sZGVyIiwib25DbGljayIsInR5cGUiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(pages-dir-node)/./components/withdraw.js\n");

/***/ }),

/***/ "(pages-dir-node)/./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES&page=%2F&preferredRegion=&absolutePagePath=.%2Fpages%5Cindex.js&absoluteAppPath=private-next-pages%2F_app&absoluteDocumentPath=private-next-pages%2F_document&middlewareConfigBase64=e30%3D!":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES&page=%2F&preferredRegion=&absolutePagePath=.%2Fpages%5Cindex.js&absoluteAppPath=private-next-pages%2F_app&absoluteDocumentPath=private-next-pages%2F_document&middlewareConfigBase64=e30%3D! ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   config: () => (/* binding */ config),\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__),\n/* harmony export */   getServerSideProps: () => (/* binding */ getServerSideProps),\n/* harmony export */   getStaticPaths: () => (/* binding */ getStaticPaths),\n/* harmony export */   getStaticProps: () => (/* binding */ getStaticProps),\n/* harmony export */   handler: () => (/* binding */ handler),\n/* harmony export */   reportWebVitals: () => (/* binding */ reportWebVitals),\n/* harmony export */   routeModule: () => (/* binding */ routeModule),\n/* harmony export */   unstable_getServerProps: () => (/* binding */ unstable_getServerProps),\n/* harmony export */   unstable_getServerSideProps: () => (/* binding */ unstable_getServerSideProps),\n/* harmony export */   unstable_getStaticParams: () => (/* binding */ unstable_getStaticParams),\n/* harmony export */   unstable_getStaticPaths: () => (/* binding */ unstable_getStaticPaths),\n/* harmony export */   unstable_getStaticProps: () => (/* binding */ unstable_getStaticProps)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_route_modules_pages_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/route-modules/pages/module.compiled */ \"(pages-dir-node)/./node_modules/next/dist/server/route-modules/pages/module.compiled.js\");\n/* harmony import */ var next_dist_server_route_modules_pages_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_route_modules_pages_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/route-kind */ \"(pages-dir-node)/./node_modules/next/dist/server/route-kind.js\");\n/* harmony import */ var next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/build/templates/helpers */ \"(pages-dir-node)/./node_modules/next/dist/build/templates/helpers.js\");\n/* harmony import */ var private_next_pages_document__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! private-next-pages/_document */ \"(pages-dir-node)/./pages/_document.js\");\n/* harmony import */ var private_next_pages_app__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! private-next-pages/_app */ \"(pages-dir-node)/./pages/_app.js\");\n/* harmony import */ var _pages_index_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pages\\index.js */ \"(pages-dir-node)/./pages/index.js\");\n/* harmony import */ var next_dist_server_route_modules_pages_pages_handler__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! next/dist/server/route-modules/pages/pages-handler */ \"(pages-dir-node)/./node_modules/next/dist/server/route-modules/pages/pages-handler.js\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pages_index_js__WEBPACK_IMPORTED_MODULE_5__]);\n_pages_index_js__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\n// Import the app and document modules.\n\n\n// Import the userland code.\n\n\n// Re-export the component (should be the default export).\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_js__WEBPACK_IMPORTED_MODULE_5__, 'default'));\n// Re-export methods.\nconst getStaticProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_js__WEBPACK_IMPORTED_MODULE_5__, 'getStaticProps');\nconst getStaticPaths = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_js__WEBPACK_IMPORTED_MODULE_5__, 'getStaticPaths');\nconst getServerSideProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_js__WEBPACK_IMPORTED_MODULE_5__, 'getServerSideProps');\nconst config = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_js__WEBPACK_IMPORTED_MODULE_5__, 'config');\nconst reportWebVitals = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_js__WEBPACK_IMPORTED_MODULE_5__, 'reportWebVitals');\n// Re-export legacy methods.\nconst unstable_getStaticProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_js__WEBPACK_IMPORTED_MODULE_5__, 'unstable_getStaticProps');\nconst unstable_getStaticPaths = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_js__WEBPACK_IMPORTED_MODULE_5__, 'unstable_getStaticPaths');\nconst unstable_getStaticParams = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_js__WEBPACK_IMPORTED_MODULE_5__, 'unstable_getStaticParams');\nconst unstable_getServerProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_js__WEBPACK_IMPORTED_MODULE_5__, 'unstable_getServerProps');\nconst unstable_getServerSideProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_js__WEBPACK_IMPORTED_MODULE_5__, 'unstable_getServerSideProps');\n// Create and export the route module that will be consumed.\nconst routeModule = new next_dist_server_route_modules_pages_module_compiled__WEBPACK_IMPORTED_MODULE_0__.PagesRouteModule({\n    definition: {\n        kind: next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.PAGES,\n        page: \"/index\",\n        pathname: \"/\",\n        // The following aren't used in production.\n        bundlePath: '',\n        filename: ''\n    },\n    distDir: \".next\" || 0,\n    relativeProjectDir:  false || '',\n    components: {\n        // default export might not exist when optimized for data only\n        App: private_next_pages_app__WEBPACK_IMPORTED_MODULE_4__[\"default\"],\n        Document: private_next_pages_document__WEBPACK_IMPORTED_MODULE_3__[\"default\"]\n    },\n    userland: _pages_index_js__WEBPACK_IMPORTED_MODULE_5__\n});\nconst handler = (0,next_dist_server_route_modules_pages_pages_handler__WEBPACK_IMPORTED_MODULE_6__.getHandler)({\n    srcPage: \"/index\",\n    config,\n    userland: _pages_index_js__WEBPACK_IMPORTED_MODULE_5__,\n    routeModule,\n    getStaticPaths,\n    getStaticProps,\n    getServerSideProps\n});\n\n//# sourceMappingURL=pages.js.map\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHBhZ2VzLWRpci1ub2RlKS8uL25vZGVfbW9kdWxlcy9uZXh0L2Rpc3QvYnVpbGQvd2VicGFjay9sb2FkZXJzL25leHQtcm91dGUtbG9hZGVyL2luZGV4LmpzP2tpbmQ9UEFHRVMmcGFnZT0lMkYmcHJlZmVycmVkUmVnaW9uPSZhYnNvbHV0ZVBhZ2VQYXRoPS4lMkZwYWdlcyU1Q2luZGV4LmpzJmFic29sdXRlQXBwUGF0aD1wcml2YXRlLW5leHQtcGFnZXMlMkZfYXBwJmFic29sdXRlRG9jdW1lbnRQYXRoPXByaXZhdGUtbmV4dC1wYWdlcyUyRl9kb2N1bWVudCZtaWRkbGV3YXJlQ29uZmlnQmFzZTY0PWUzMCUzRCEiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQXdGO0FBQ2hDO0FBQ0U7QUFDMUQ7QUFDeUQ7QUFDVjtBQUMvQztBQUM4QztBQUNrQztBQUNoRjtBQUNBLGlFQUFlLHdFQUFLLENBQUMsNENBQVEsWUFBWSxFQUFDO0FBQzFDO0FBQ08sdUJBQXVCLHdFQUFLLENBQUMsNENBQVE7QUFDckMsdUJBQXVCLHdFQUFLLENBQUMsNENBQVE7QUFDckMsMkJBQTJCLHdFQUFLLENBQUMsNENBQVE7QUFDekMsZUFBZSx3RUFBSyxDQUFDLDRDQUFRO0FBQzdCLHdCQUF3Qix3RUFBSyxDQUFDLDRDQUFRO0FBQzdDO0FBQ08sZ0NBQWdDLHdFQUFLLENBQUMsNENBQVE7QUFDOUMsZ0NBQWdDLHdFQUFLLENBQUMsNENBQVE7QUFDOUMsaUNBQWlDLHdFQUFLLENBQUMsNENBQVE7QUFDL0MsZ0NBQWdDLHdFQUFLLENBQUMsNENBQVE7QUFDOUMsb0NBQW9DLHdFQUFLLENBQUMsNENBQVE7QUFDekQ7QUFDTyx3QkFBd0Isa0dBQWdCO0FBQy9DO0FBQ0EsY0FBYyxrRUFBUztBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMLGFBQWEsT0FBb0MsSUFBSSxDQUFFO0FBQ3ZELHdCQUF3QixNQUF1QztBQUMvRDtBQUNBO0FBQ0EsYUFBYSw4REFBVztBQUN4QixrQkFBa0IsbUVBQWdCO0FBQ2xDLEtBQUs7QUFDTCxZQUFZO0FBQ1osQ0FBQztBQUNNLGdCQUFnQiw4RkFBVTtBQUNqQztBQUNBO0FBQ0EsWUFBWTtBQUNaO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7QUFFRCIsInNvdXJjZXMiOlsiIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFBhZ2VzUm91dGVNb2R1bGUgfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9yb3V0ZS1tb2R1bGVzL3BhZ2VzL21vZHVsZS5jb21waWxlZFwiO1xuaW1wb3J0IHsgUm91dGVLaW5kIH0gZnJvbSBcIm5leHQvZGlzdC9zZXJ2ZXIvcm91dGUta2luZFwiO1xuaW1wb3J0IHsgaG9pc3QgfSBmcm9tIFwibmV4dC9kaXN0L2J1aWxkL3RlbXBsYXRlcy9oZWxwZXJzXCI7XG4vLyBJbXBvcnQgdGhlIGFwcCBhbmQgZG9jdW1lbnQgbW9kdWxlcy5cbmltcG9ydCAqIGFzIGRvY3VtZW50IGZyb20gXCJwcml2YXRlLW5leHQtcGFnZXMvX2RvY3VtZW50XCI7XG5pbXBvcnQgKiBhcyBhcHAgZnJvbSBcInByaXZhdGUtbmV4dC1wYWdlcy9fYXBwXCI7XG4vLyBJbXBvcnQgdGhlIHVzZXJsYW5kIGNvZGUuXG5pbXBvcnQgKiBhcyB1c2VybGFuZCBmcm9tIFwiLi9wYWdlc1xcXFxpbmRleC5qc1wiO1xuaW1wb3J0IHsgZ2V0SGFuZGxlciB9IGZyb20gXCJuZXh0L2Rpc3Qvc2VydmVyL3JvdXRlLW1vZHVsZXMvcGFnZXMvcGFnZXMtaGFuZGxlclwiO1xuLy8gUmUtZXhwb3J0IHRoZSBjb21wb25lbnQgKHNob3VsZCBiZSB0aGUgZGVmYXVsdCBleHBvcnQpLlxuZXhwb3J0IGRlZmF1bHQgaG9pc3QodXNlcmxhbmQsICdkZWZhdWx0Jyk7XG4vLyBSZS1leHBvcnQgbWV0aG9kcy5cbmV4cG9ydCBjb25zdCBnZXRTdGF0aWNQcm9wcyA9IGhvaXN0KHVzZXJsYW5kLCAnZ2V0U3RhdGljUHJvcHMnKTtcbmV4cG9ydCBjb25zdCBnZXRTdGF0aWNQYXRocyA9IGhvaXN0KHVzZXJsYW5kLCAnZ2V0U3RhdGljUGF0aHMnKTtcbmV4cG9ydCBjb25zdCBnZXRTZXJ2ZXJTaWRlUHJvcHMgPSBob2lzdCh1c2VybGFuZCwgJ2dldFNlcnZlclNpZGVQcm9wcycpO1xuZXhwb3J0IGNvbnN0IGNvbmZpZyA9IGhvaXN0KHVzZXJsYW5kLCAnY29uZmlnJyk7XG5leHBvcnQgY29uc3QgcmVwb3J0V2ViVml0YWxzID0gaG9pc3QodXNlcmxhbmQsICdyZXBvcnRXZWJWaXRhbHMnKTtcbi8vIFJlLWV4cG9ydCBsZWdhY3kgbWV0aG9kcy5cbmV4cG9ydCBjb25zdCB1bnN0YWJsZV9nZXRTdGF0aWNQcm9wcyA9IGhvaXN0KHVzZXJsYW5kLCAndW5zdGFibGVfZ2V0U3RhdGljUHJvcHMnKTtcbmV4cG9ydCBjb25zdCB1bnN0YWJsZV9nZXRTdGF0aWNQYXRocyA9IGhvaXN0KHVzZXJsYW5kLCAndW5zdGFibGVfZ2V0U3RhdGljUGF0aHMnKTtcbmV4cG9ydCBjb25zdCB1bnN0YWJsZV9nZXRTdGF0aWNQYXJhbXMgPSBob2lzdCh1c2VybGFuZCwgJ3Vuc3RhYmxlX2dldFN0YXRpY1BhcmFtcycpO1xuZXhwb3J0IGNvbnN0IHVuc3RhYmxlX2dldFNlcnZlclByb3BzID0gaG9pc3QodXNlcmxhbmQsICd1bnN0YWJsZV9nZXRTZXJ2ZXJQcm9wcycpO1xuZXhwb3J0IGNvbnN0IHVuc3RhYmxlX2dldFNlcnZlclNpZGVQcm9wcyA9IGhvaXN0KHVzZXJsYW5kLCAndW5zdGFibGVfZ2V0U2VydmVyU2lkZVByb3BzJyk7XG4vLyBDcmVhdGUgYW5kIGV4cG9ydCB0aGUgcm91dGUgbW9kdWxlIHRoYXQgd2lsbCBiZSBjb25zdW1lZC5cbmV4cG9ydCBjb25zdCByb3V0ZU1vZHVsZSA9IG5ldyBQYWdlc1JvdXRlTW9kdWxlKHtcbiAgICBkZWZpbml0aW9uOiB7XG4gICAgICAgIGtpbmQ6IFJvdXRlS2luZC5QQUdFUyxcbiAgICAgICAgcGFnZTogXCIvaW5kZXhcIixcbiAgICAgICAgcGF0aG5hbWU6IFwiL1wiLFxuICAgICAgICAvLyBUaGUgZm9sbG93aW5nIGFyZW4ndCB1c2VkIGluIHByb2R1Y3Rpb24uXG4gICAgICAgIGJ1bmRsZVBhdGg6ICcnLFxuICAgICAgICBmaWxlbmFtZTogJydcbiAgICB9LFxuICAgIGRpc3REaXI6IHByb2Nlc3MuZW52Ll9fTkVYVF9SRUxBVElWRV9ESVNUX0RJUiB8fCAnJyxcbiAgICByZWxhdGl2ZVByb2plY3REaXI6IHByb2Nlc3MuZW52Ll9fTkVYVF9SRUxBVElWRV9QUk9KRUNUX0RJUiB8fCAnJyxcbiAgICBjb21wb25lbnRzOiB7XG4gICAgICAgIC8vIGRlZmF1bHQgZXhwb3J0IG1pZ2h0IG5vdCBleGlzdCB3aGVuIG9wdGltaXplZCBmb3IgZGF0YSBvbmx5XG4gICAgICAgIEFwcDogYXBwLmRlZmF1bHQsXG4gICAgICAgIERvY3VtZW50OiBkb2N1bWVudC5kZWZhdWx0XG4gICAgfSxcbiAgICB1c2VybGFuZFxufSk7XG5leHBvcnQgY29uc3QgaGFuZGxlciA9IGdldEhhbmRsZXIoe1xuICAgIHNyY1BhZ2U6IFwiL2luZGV4XCIsXG4gICAgY29uZmlnLFxuICAgIHVzZXJsYW5kLFxuICAgIHJvdXRlTW9kdWxlLFxuICAgIGdldFN0YXRpY1BhdGhzLFxuICAgIGdldFN0YXRpY1Byb3BzLFxuICAgIGdldFNlcnZlclNpZGVQcm9wc1xufSk7XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXBhZ2VzLmpzLm1hcFxuIl0sIm5hbWVzIjpbXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(pages-dir-node)/./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES&page=%2F&preferredRegion=&absolutePagePath=.%2Fpages%5Cindex.js&absoluteAppPath=private-next-pages%2F_app&absoluteDocumentPath=private-next-pages%2F_document&middlewareConfigBase64=e30%3D!\n");

/***/ }),

/***/ "(pages-dir-node)/./pages/_app.js":
/*!***********************!*\
  !*** ./pages/_app.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ App)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/styles/globals.css */ \"(pages-dir-node)/./styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_1__);\n\n\nfunction App({ Component, pageProps }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n        ...pageProps\n    }, void 0, false, {\n        fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\pages\\\\_app.js\",\n        lineNumber: 4,\n        columnNumber: 10\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHBhZ2VzLWRpci1ub2RlKS8uL3BhZ2VzL19hcHAuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQThCO0FBRWYsU0FBU0EsSUFBSSxFQUFFQyxTQUFTLEVBQUVDLFNBQVMsRUFBRTtJQUNsRCxxQkFBTyw4REFBQ0Q7UUFBVyxHQUFHQyxTQUFTOzs7Ozs7QUFDakMiLCJzb3VyY2VzIjpbIkM6XFxtaW5lXFx3ZWJyb290XFxkZW1vXFxob21ld29ya1xcdGVzdDFcXHBhZ2VzXFxfYXBwLmpzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBcIkAvc3R5bGVzL2dsb2JhbHMuY3NzXCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFwcCh7IENvbXBvbmVudCwgcGFnZVByb3BzIH0pIHtcbiAgcmV0dXJuIDxDb21wb25lbnQgey4uLnBhZ2VQcm9wc30gLz47XG59XG4iXSwibmFtZXMiOlsiQXBwIiwiQ29tcG9uZW50IiwicGFnZVByb3BzIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(pages-dir-node)/./pages/_app.js\n");

/***/ }),

/***/ "(pages-dir-node)/./pages/_document.js":
/*!****************************!*\
  !*** ./pages/_document.js ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Document)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_document__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/document */ \"(pages-dir-node)/./node_modules/next/document.js\");\n/* harmony import */ var next_document__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_document__WEBPACK_IMPORTED_MODULE_1__);\n\n\nfunction Document() {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_document__WEBPACK_IMPORTED_MODULE_1__.Html, {\n        lang: \"en\",\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_document__WEBPACK_IMPORTED_MODULE_1__.Head, {}, void 0, false, {\n                fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\pages\\\\_document.js\",\n                lineNumber: 6,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"body\", {\n                className: \"antialiased\",\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_document__WEBPACK_IMPORTED_MODULE_1__.Main, {}, void 0, false, {\n                        fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\pages\\\\_document.js\",\n                        lineNumber: 8,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_document__WEBPACK_IMPORTED_MODULE_1__.NextScript, {}, void 0, false, {\n                        fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\pages\\\\_document.js\",\n                        lineNumber: 9,\n                        columnNumber: 9\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\pages\\\\_document.js\",\n                lineNumber: 7,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\pages\\\\_document.js\",\n        lineNumber: 5,\n        columnNumber: 5\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHBhZ2VzLWRpci1ub2RlKS8uL3BhZ2VzL19kb2N1bWVudC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBNkQ7QUFFOUMsU0FBU0k7SUFDdEIscUJBQ0UsOERBQUNKLCtDQUFJQTtRQUFDSyxNQUFLOzswQkFDVCw4REFBQ0osK0NBQUlBOzs7OzswQkFDTCw4REFBQ0s7Z0JBQUtDLFdBQVU7O2tDQUNkLDhEQUFDTCwrQ0FBSUE7Ozs7O2tDQUNMLDhEQUFDQyxxREFBVUE7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBSW5CIiwic291cmNlcyI6WyJDOlxcbWluZVxcd2Vicm9vdFxcZGVtb1xcaG9tZXdvcmtcXHRlc3QxXFxwYWdlc1xcX2RvY3VtZW50LmpzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEh0bWwsIEhlYWQsIE1haW4sIE5leHRTY3JpcHQgfSBmcm9tIFwibmV4dC9kb2N1bWVudFwiO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBEb2N1bWVudCgpIHtcbiAgcmV0dXJuIChcbiAgICA8SHRtbCBsYW5nPVwiZW5cIj5cbiAgICAgIDxIZWFkIC8+XG4gICAgICA8Ym9keSBjbGFzc05hbWU9XCJhbnRpYWxpYXNlZFwiPlxuICAgICAgICA8TWFpbiAvPlxuICAgICAgICA8TmV4dFNjcmlwdCAvPlxuICAgICAgPC9ib2R5PlxuICAgIDwvSHRtbD5cbiAgKTtcbn1cbiJdLCJuYW1lcyI6WyJIdG1sIiwiSGVhZCIsIk1haW4iLCJOZXh0U2NyaXB0IiwiRG9jdW1lbnQiLCJsYW5nIiwiYm9keSIsImNsYXNzTmFtZSJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(pages-dir-node)/./pages/_document.js\n");

/***/ }),

/***/ "(pages-dir-node)/./pages/home/index.js":
/*!*****************************!*\
  !*** ./pages/home/index.js ***!
  \*****************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Home)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _barrel_optimize_names_Button_Input_antd__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! __barrel_optimize__?names=Button,Input!=!antd */ \"(pages-dir-node)/__barrel_optimize__?names=Button,Input!=!./node_modules/antd/lib/index.js\");\n/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ethers */ \"ethers\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _barrel_optimize_names_Tabs_antd__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! __barrel_optimize__?names=Tabs!=!antd */ \"(pages-dir-node)/__barrel_optimize__?names=Tabs!=!./node_modules/antd/lib/index.js\");\n/* harmony import */ var _components_withdraw__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/components/withdraw */ \"(pages-dir-node)/./components/withdraw.js\");\n/* harmony import */ var _components_deposit__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/components/deposit */ \"(pages-dir-node)/./components/deposit.js\");\n/* harmony import */ var _components_claim__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/components/claim */ \"(pages-dir-node)/./components/claim.js\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([ethers__WEBPACK_IMPORTED_MODULE_1__, _components_withdraw__WEBPACK_IMPORTED_MODULE_3__, _components_deposit__WEBPACK_IMPORTED_MODULE_4__, _components_claim__WEBPACK_IMPORTED_MODULE_5__]);\n([ethers__WEBPACK_IMPORTED_MODULE_1__, _components_withdraw__WEBPACK_IMPORTED_MODULE_3__, _components_deposit__WEBPACK_IMPORTED_MODULE_4__, _components_claim__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\n\n\n\n\n\nlet newProvider;\nfunction Home() {\n    const [account, setAccount] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(null);\n    const [balance, setbalance] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(null);\n    const items = [\n        {\n            key: \"1\",\n            label: \"质押\",\n            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_deposit__WEBPACK_IMPORTED_MODULE_4__[\"default\"], {\n                newProvider: newProvider,\n                account: account\n            }, void 0, false, {\n                fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\pages\\\\home\\\\index.js\",\n                lineNumber: 16,\n                columnNumber: 17\n            }, this)\n        },\n        {\n            key: \"2\",\n            label: \"取款\",\n            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_withdraw__WEBPACK_IMPORTED_MODULE_3__[\"default\"], {\n                newProvider: newProvider,\n                account: account\n            }, void 0, false, {\n                fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\pages\\\\home\\\\index.js\",\n                lineNumber: 21,\n                columnNumber: 17\n            }, this)\n        },\n        {\n            key: \"3\",\n            label: \"收益\",\n            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_claim__WEBPACK_IMPORTED_MODULE_5__[\"default\"], {\n                newProvider: newProvider,\n                account: account\n            }, void 0, false, {\n                fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\pages\\\\home\\\\index.js\",\n                lineNumber: 26,\n                columnNumber: 16\n            }, this)\n        }\n    ];\n    async function connectWallet() {\n        try {\n            console.log(\"连接钱包\");\n            // 检查是否安装了MetaMask\n            if (!window.ethereum) {\n                throw new Error(\"请安装MetaMask钱包\");\n            }\n            // 请求连接钱包\n            const accounts = await window.ethereum.request({\n                method: \"eth_requestAccounts\"\n            });\n            if (accounts.length > 0) {\n                newProvider = new ethers__WEBPACK_IMPORTED_MODULE_1__.ethers.BrowserProvider(window.ethereum);\n                const signer = await newProvider.getSigner();\n                const address = await signer.getAddress();\n                const balance = await newProvider.getBalance(address);\n                setAccount(address);\n                setbalance(ethers__WEBPACK_IMPORTED_MODULE_1__.ethers.formatEther(balance));\n                console.log(\"钱包连接成功:\", address);\n            }\n        } catch (error) {\n            console.error(\"连接钱包失败:\", error);\n        }\n    }\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n            className: \"w-[800px] mx-auto\",\n            children: [\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                    className: \"flex items-center my-[20px]\",\n                    children: [\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Input_antd__WEBPACK_IMPORTED_MODULE_6__.Button, {\n                            onClick: connectWallet,\n                            type: \"primary\",\n                            children: \"连接钱包\"\n                        }, void 0, false, {\n                            fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\pages\\\\home\\\\index.js\",\n                            lineNumber: 61,\n                            columnNumber: 11\n                        }, this),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                            children: [\n                                \"\\xa0钱包地址：\",\n                                account,\n                                \" \"\n                            ]\n                        }, void 0, true, {\n                            fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\pages\\\\home\\\\index.js\",\n                            lineNumber: 64,\n                            columnNumber: 11\n                        }, this),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                            children: [\n                                \"\\xa0钱包余额：\",\n                                balance\n                            ]\n                        }, void 0, true, {\n                            fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\pages\\\\home\\\\index.js\",\n                            lineNumber: 65,\n                            columnNumber: 11\n                        }, this)\n                    ]\n                }, void 0, true, {\n                    fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\pages\\\\home\\\\index.js\",\n                    lineNumber: 60,\n                    columnNumber: 9\n                }, this),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Tabs_antd__WEBPACK_IMPORTED_MODULE_7__.Tabs, {\n                    items: items,\n                    centered: true\n                }, void 0, false, {\n                    fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\pages\\\\home\\\\index.js\",\n                    lineNumber: 68,\n                    columnNumber: 9\n                }, this)\n            ]\n        }, void 0, true, {\n            fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\pages\\\\home\\\\index.js\",\n            lineNumber: 59,\n            columnNumber: 7\n        }, this)\n    }, void 0, false);\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHBhZ2VzLWRpci1ub2RlKS8uL3BhZ2VzL2hvbWUvaW5kZXguanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQXFDO0FBQ0w7QUFDWTtBQUNoQjtBQUNpQjtBQUNIO0FBQ0g7QUFDdkMsSUFBSVM7QUFDVyxTQUFTQztJQUN0QixNQUFNLENBQUNDLFNBQVNDLFdBQVcsR0FBR1IsK0NBQVFBLENBQUM7SUFDdkMsTUFBTSxDQUFDUyxTQUFTQyxXQUFXLEdBQUdWLCtDQUFRQSxDQUFDO0lBQ3ZDLE1BQU1XLFFBQVE7UUFDWjtZQUNFQyxLQUFLO1lBQ0xDLE9BQU87WUFDUEMsd0JBQVUsOERBQUNYLDJEQUFPQTtnQkFBQ0UsYUFBYUE7Z0JBQWFFLFNBQVNBOzs7Ozs7UUFDeEQ7UUFDQTtZQUNFSyxLQUFLO1lBQ0xDLE9BQU87WUFDUEMsd0JBQVUsOERBQUNaLDREQUFRQTtnQkFBQ0csYUFBYUE7Z0JBQWFFLFNBQVNBOzs7Ozs7UUFDekQ7UUFDQTtZQUNFSyxLQUFJO1lBQ0pDLE9BQU07WUFDTkMsd0JBQVMsOERBQUNWLHlEQUFLQTtnQkFBQ0MsYUFBYUE7Z0JBQWFFLFNBQVNBOzs7Ozs7UUFDckQ7S0FDRDtJQUVELGVBQWVRO1FBQ2IsSUFBSTtZQUNGQyxRQUFRQyxHQUFHLENBQUM7WUFDWixrQkFBa0I7WUFDbEIsSUFBSSxDQUFDQyxPQUFPQyxRQUFRLEVBQUU7Z0JBQ3BCLE1BQU0sSUFBSUMsTUFBTTtZQUNsQjtZQUVBLFNBQVM7WUFDVCxNQUFNQyxXQUFXLE1BQU1ILE9BQU9DLFFBQVEsQ0FBQ0csT0FBTyxDQUFDO2dCQUM3Q0MsUUFBUTtZQUNWO1lBRUEsSUFBSUYsU0FBU0csTUFBTSxHQUFHLEdBQUc7Z0JBQ3ZCbkIsY0FBYyxJQUFJUCwwQ0FBTUEsQ0FBQzJCLGVBQWUsQ0FBQ1AsT0FBT0MsUUFBUTtnQkFFeEQsTUFBTU8sU0FBUyxNQUFNckIsWUFBWXNCLFNBQVM7Z0JBQzFDLE1BQU1DLFVBQVUsTUFBTUYsT0FBT0csVUFBVTtnQkFDdkMsTUFBTXBCLFVBQVUsTUFBTUosWUFBWXlCLFVBQVUsQ0FBQ0Y7Z0JBQzdDcEIsV0FBV29CO2dCQUNYbEIsV0FBV1osMENBQU1BLENBQUNpQyxXQUFXLENBQUN0QjtnQkFDOUJPLFFBQVFDLEdBQUcsQ0FBQyxXQUFXVztZQUN6QjtRQUNGLEVBQUUsT0FBT0ksT0FBTztZQUNkaEIsUUFBUWdCLEtBQUssQ0FBQyxXQUFXQTtRQUMzQjtJQUNGO0lBQ0EscUJBQ0U7a0JBQ0UsNEVBQUNDO1lBQUlDLFdBQVU7OzhCQUNiLDhEQUFDRDtvQkFBSUMsV0FBVTs7c0NBQ2IsOERBQUN0Qyw0RUFBTUE7NEJBQUN1QyxTQUFTcEI7NEJBQWVxQixNQUFLO3NDQUFVOzs7Ozs7c0NBRy9DLDhEQUFDSDs7Z0NBQUk7Z0NBQVkxQjtnQ0FBUTs7Ozs7OztzQ0FDekIsOERBQUMwQjs7Z0NBQUk7Z0NBQVl4Qjs7Ozs7Ozs7Ozs7Ozs4QkFHbkIsOERBQUNSLGtFQUFJQTtvQkFBQ1UsT0FBT0E7b0JBQU8wQixRQUFROzs7Ozs7Ozs7Ozs7O0FBSXBDIiwic291cmNlcyI6WyJDOlxcbWluZVxcd2Vicm9vdFxcZGVtb1xcaG9tZXdvcmtcXHRlc3QxXFxwYWdlc1xcaG9tZVxcaW5kZXguanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQnV0dG9uLCBJbnB1dCB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7IGV0aGVycyB9IGZyb20gXCJldGhlcnNcIjtcclxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBUYWJzIH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IFdpdGhkcmF3IGZyb20gXCJAL2NvbXBvbmVudHMvd2l0aGRyYXdcIjtcclxuaW1wb3J0IERlcG9zaXQgZnJvbSAnQC9jb21wb25lbnRzL2RlcG9zaXQnXHJcbmltcG9ydCBDbGFpbSBmcm9tIFwiQC9jb21wb25lbnRzL2NsYWltXCI7XHJcbmxldCBuZXdQcm92aWRlcjtcclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSG9tZSgpIHtcclxuICBjb25zdCBbYWNjb3VudCwgc2V0QWNjb3VudF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbYmFsYW5jZSwgc2V0YmFsYW5jZV0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBpdGVtcyA9IFtcclxuICAgIHtcclxuICAgICAga2V5OiBcIjFcIixcclxuICAgICAgbGFiZWw6IFwi6LSo5oq8XCIsXHJcbiAgICAgIGNoaWxkcmVuOiA8RGVwb3NpdCBuZXdQcm92aWRlcj17bmV3UHJvdmlkZXJ9IGFjY291bnQ9e2FjY291bnR9Lz4sXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBrZXk6IFwiMlwiLFxyXG4gICAgICBsYWJlbDogXCLlj5bmrL5cIixcclxuICAgICAgY2hpbGRyZW46IDxXaXRoZHJhdyBuZXdQcm92aWRlcj17bmV3UHJvdmlkZXJ9IGFjY291bnQ9e2FjY291bnR9IC8+LFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAga2V5OlwiM1wiLFxyXG4gICAgICBsYWJlbDpcIuaUtuebilwiLFxyXG4gICAgICBjaGlsZHJlbjo8Q2xhaW0gbmV3UHJvdmlkZXI9e25ld1Byb3ZpZGVyfSBhY2NvdW50PXthY2NvdW50fT48L0NsYWltPlxyXG4gICAgfVxyXG4gIF07XHJcblxyXG4gIGFzeW5jIGZ1bmN0aW9uIGNvbm5lY3RXYWxsZXQoKSB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zb2xlLmxvZyhcIui/nuaOpemSseWMhVwiKTtcclxuICAgICAgLy8g5qOA5p+l5piv5ZCm5a6J6KOF5LqGTWV0YU1hc2tcclxuICAgICAgaWYgKCF3aW5kb3cuZXRoZXJldW0pIHtcclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCLor7flronoo4VNZXRhTWFza+mSseWMhVwiKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgLy8g6K+35rGC6L+e5o6l6ZKx5YyFXHJcbiAgICAgIGNvbnN0IGFjY291bnRzID0gYXdhaXQgd2luZG93LmV0aGVyZXVtLnJlcXVlc3Qoe1xyXG4gICAgICAgIG1ldGhvZDogXCJldGhfcmVxdWVzdEFjY291bnRzXCIsXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgaWYgKGFjY291bnRzLmxlbmd0aCA+IDApIHtcclxuICAgICAgICBuZXdQcm92aWRlciA9IG5ldyBldGhlcnMuQnJvd3NlclByb3ZpZGVyKHdpbmRvdy5ldGhlcmV1bSk7XHJcblxyXG4gICAgICAgIGNvbnN0IHNpZ25lciA9IGF3YWl0IG5ld1Byb3ZpZGVyLmdldFNpZ25lcigpO1xyXG4gICAgICAgIGNvbnN0IGFkZHJlc3MgPSBhd2FpdCBzaWduZXIuZ2V0QWRkcmVzcygpO1xyXG4gICAgICAgIGNvbnN0IGJhbGFuY2UgPSBhd2FpdCBuZXdQcm92aWRlci5nZXRCYWxhbmNlKGFkZHJlc3MpO1xyXG4gICAgICAgIHNldEFjY291bnQoYWRkcmVzcyk7XHJcbiAgICAgICAgc2V0YmFsYW5jZShldGhlcnMuZm9ybWF0RXRoZXIoYmFsYW5jZSkpO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwi6ZKx5YyF6L+e5o6l5oiQ5YqfOlwiLCBhZGRyZXNzKTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIui/nuaOpemSseWMheWksei0pTpcIiwgZXJyb3IpO1xyXG4gICAgfVxyXG4gIH1cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LVs4MDBweF0gbXgtYXV0b1wiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgbXktWzIwcHhdXCI+XHJcbiAgICAgICAgICA8QnV0dG9uIG9uQ2xpY2s9e2Nvbm5lY3RXYWxsZXR9IHR5cGU9XCJwcmltYXJ5XCI+XHJcbiAgICAgICAgICAgIOi/nuaOpemSseWMhVxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICA8ZGl2PiZuYnNwO+mSseWMheWcsOWdgO+8mnthY2NvdW50fSA8L2Rpdj5cclxuICAgICAgICAgIDxkaXY+Jm5ic3A76ZKx5YyF5L2Z6aKd77yae2JhbGFuY2V9PC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxUYWJzIGl0ZW1zPXtpdGVtc30gY2VudGVyZWQgLz5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8Lz5cclxuICApO1xyXG59XHJcbiJdLCJuYW1lcyI6WyJCdXR0b24iLCJJbnB1dCIsImV0aGVycyIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiVGFicyIsIldpdGhkcmF3IiwiRGVwb3NpdCIsIkNsYWltIiwibmV3UHJvdmlkZXIiLCJIb21lIiwiYWNjb3VudCIsInNldEFjY291bnQiLCJiYWxhbmNlIiwic2V0YmFsYW5jZSIsIml0ZW1zIiwia2V5IiwibGFiZWwiLCJjaGlsZHJlbiIsImNvbm5lY3RXYWxsZXQiLCJjb25zb2xlIiwibG9nIiwid2luZG93IiwiZXRoZXJldW0iLCJFcnJvciIsImFjY291bnRzIiwicmVxdWVzdCIsIm1ldGhvZCIsImxlbmd0aCIsIkJyb3dzZXJQcm92aWRlciIsInNpZ25lciIsImdldFNpZ25lciIsImFkZHJlc3MiLCJnZXRBZGRyZXNzIiwiZ2V0QmFsYW5jZSIsImZvcm1hdEV0aGVyIiwiZXJyb3IiLCJkaXYiLCJjbGFzc05hbWUiLCJvbkNsaWNrIiwidHlwZSIsImNlbnRlcmVkIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(pages-dir-node)/./pages/home/index.js\n");

/***/ }),

/***/ "(pages-dir-node)/./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Home)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _home_index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home/index */ \"(pages-dir-node)/./pages/home/index.js\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_home_index__WEBPACK_IMPORTED_MODULE_1__]);\n_home_index__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\nfunction Home() {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_home_index__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {}, void 0, false, {\n            fileName: \"C:\\\\mine\\\\webroot\\\\demo\\\\homework\\\\test1\\\\pages\\\\index.js\",\n            lineNumber: 6,\n            columnNumber: 5\n        }, this)\n    }, void 0, false);\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHBhZ2VzLWRpci1ub2RlKS8uL3BhZ2VzL2luZGV4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7O0FBQStCO0FBQ2hCLFNBQVNDO0lBRXRCLHFCQUNFO2tCQUNBLDRFQUFDRCxtREFBSUE7Ozs7OztBQUdUIiwic291cmNlcyI6WyJDOlxcbWluZVxcd2Vicm9vdFxcZGVtb1xcaG9tZXdvcmtcXHRlc3QxXFxwYWdlc1xcaW5kZXguanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFBhZ2UgZnJvbSAnLi9ob21lL2luZGV4J1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSG9tZSgpIHtcbiAgXG4gIHJldHVybiAoXG4gICAgPD5cbiAgICA8UGFnZS8+XG4gICAgPC8+XG4gICk7XG59XG4iXSwibmFtZXMiOlsiUGFnZSIsIkhvbWUiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(pages-dir-node)/./pages/index.js\n");

/***/ }),

/***/ "(pages-dir-node)/./styles/globals.css":
/*!****************************!*\
  !*** ./styles/globals.css ***!
  \****************************/
/***/ (() => {



/***/ }),

/***/ "(pages-dir-node)/__barrel_optimize__?names=Button,Input!=!./node_modules/antd/lib/index.js":
/*!*********************************************************************************!*\
  !*** __barrel_optimize__?names=Button,Input!=!./node_modules/antd/lib/index.js ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var C_mine_webroot_demo_homework_test1_node_modules_antd_lib_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/antd/lib/index.js */ "(pages-dir-node)/./node_modules/antd/lib/index.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in C_mine_webroot_demo_homework_test1_node_modules_antd_lib_index_js__WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => C_mine_webroot_demo_homework_test1_node_modules_antd_lib_index_js__WEBPACK_IMPORTED_MODULE_0__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);


/***/ }),

/***/ "(pages-dir-node)/__barrel_optimize__?names=Button,Input,Modal,Spin!=!./node_modules/antd/lib/index.js":
/*!********************************************************************************************!*\
  !*** __barrel_optimize__?names=Button,Input,Modal,Spin!=!./node_modules/antd/lib/index.js ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var C_mine_webroot_demo_homework_test1_node_modules_antd_lib_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/antd/lib/index.js */ "(pages-dir-node)/./node_modules/antd/lib/index.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in C_mine_webroot_demo_homework_test1_node_modules_antd_lib_index_js__WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => C_mine_webroot_demo_homework_test1_node_modules_antd_lib_index_js__WEBPACK_IMPORTED_MODULE_0__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);


/***/ }),

/***/ "(pages-dir-node)/__barrel_optimize__?names=Card!=!./node_modules/antd/lib/index.js":
/*!*************************************************************************!*\
  !*** __barrel_optimize__?names=Card!=!./node_modules/antd/lib/index.js ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var C_mine_webroot_demo_homework_test1_node_modules_antd_lib_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/antd/lib/index.js */ "(pages-dir-node)/./node_modules/antd/lib/index.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in C_mine_webroot_demo_homework_test1_node_modules_antd_lib_index_js__WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => C_mine_webroot_demo_homework_test1_node_modules_antd_lib_index_js__WEBPACK_IMPORTED_MODULE_0__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);


/***/ }),

/***/ "(pages-dir-node)/__barrel_optimize__?names=Tabs!=!./node_modules/antd/lib/index.js":
/*!*************************************************************************!*\
  !*** __barrel_optimize__?names=Tabs!=!./node_modules/antd/lib/index.js ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var C_mine_webroot_demo_homework_test1_node_modules_antd_lib_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/antd/lib/index.js */ "(pages-dir-node)/./node_modules/antd/lib/index.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in C_mine_webroot_demo_homework_test1_node_modules_antd_lib_index_js__WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => C_mine_webroot_demo_homework_test1_node_modules_antd_lib_index_js__WEBPACK_IMPORTED_MODULE_0__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);


/***/ }),

/***/ "../../../shared/lib/no-fallback-error.external":
/*!*********************************************************************!*\
  !*** external "next/dist/shared/lib/no-fallback-error.external.js" ***!
  \*********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/no-fallback-error.external.js");

/***/ }),

/***/ "@ant-design/colors":
/*!*************************************!*\
  !*** external "@ant-design/colors" ***!
  \*************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/colors");

/***/ }),

/***/ "@ant-design/cssinjs":
/*!**************************************!*\
  !*** external "@ant-design/cssinjs" ***!
  \**************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/cssinjs");

/***/ }),

/***/ "@ant-design/cssinjs-utils":
/*!********************************************!*\
  !*** external "@ant-design/cssinjs-utils" ***!
  \********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/cssinjs-utils");

/***/ }),

/***/ "@ant-design/fast-color":
/*!*****************************************!*\
  !*** external "@ant-design/fast-color" ***!
  \*****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/fast-color");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/BarsOutlined":
/*!*************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/BarsOutlined" ***!
  \*************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/BarsOutlined");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/CalendarOutlined":
/*!*****************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/CalendarOutlined" ***!
  \*****************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/CalendarOutlined");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/CaretDownFilled":
/*!****************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/CaretDownFilled" ***!
  \****************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/CaretDownFilled");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/CaretDownOutlined":
/*!******************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/CaretDownOutlined" ***!
  \******************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/CaretDownOutlined");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/CaretUpOutlined":
/*!****************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/CaretUpOutlined" ***!
  \****************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/CaretUpOutlined");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/CheckCircleFilled":
/*!******************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/CheckCircleFilled" ***!
  \******************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/CheckCircleFilled");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/CheckOutlined":
/*!**************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/CheckOutlined" ***!
  \**************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/CheckOutlined");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/ClockCircleOutlined":
/*!********************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/ClockCircleOutlined" ***!
  \********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/ClockCircleOutlined");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/CloseCircleFilled":
/*!******************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/CloseCircleFilled" ***!
  \******************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/CloseCircleFilled");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/CloseOutlined":
/*!**************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/CloseOutlined" ***!
  \**************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/CloseOutlined");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/CopyOutlined":
/*!*************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/CopyOutlined" ***!
  \*************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/CopyOutlined");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/DeleteOutlined":
/*!***************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/DeleteOutlined" ***!
  \***************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/DeleteOutlined");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/DoubleLeftOutlined":
/*!*******************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/DoubleLeftOutlined" ***!
  \*******************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/DoubleLeftOutlined");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/DoubleRightOutlined":
/*!********************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/DoubleRightOutlined" ***!
  \********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/DoubleRightOutlined");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/DownOutlined":
/*!*************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/DownOutlined" ***!
  \*************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/DownOutlined");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/DownloadOutlined":
/*!*****************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/DownloadOutlined" ***!
  \*****************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/DownloadOutlined");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/EditOutlined":
/*!*************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/EditOutlined" ***!
  \*************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/EditOutlined");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/EllipsisOutlined":
/*!*****************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/EllipsisOutlined" ***!
  \*****************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/EllipsisOutlined");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/EnterOutlined":
/*!**************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/EnterOutlined" ***!
  \**************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/EnterOutlined");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/ExclamationCircleFilled":
/*!************************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/ExclamationCircleFilled" ***!
  \************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/ExclamationCircleFilled");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/EyeInvisibleOutlined":
/*!*********************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/EyeInvisibleOutlined" ***!
  \*********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/EyeInvisibleOutlined");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/EyeOutlined":
/*!************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/EyeOutlined" ***!
  \************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/EyeOutlined");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/FileOutlined":
/*!*************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/FileOutlined" ***!
  \*************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/FileOutlined");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/FileTextOutlined":
/*!*****************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/FileTextOutlined" ***!
  \*****************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/FileTextOutlined");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/FileTwoTone":
/*!************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/FileTwoTone" ***!
  \************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/FileTwoTone");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/FilterFilled":
/*!*************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/FilterFilled" ***!
  \*************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/FilterFilled");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/FolderOpenOutlined":
/*!*******************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/FolderOpenOutlined" ***!
  \*******************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/FolderOpenOutlined");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/FolderOutlined":
/*!***************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/FolderOutlined" ***!
  \***************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/FolderOutlined");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/HolderOutlined":
/*!***************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/HolderOutlined" ***!
  \***************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/HolderOutlined");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/InfoCircleFilled":
/*!*****************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/InfoCircleFilled" ***!
  \*****************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/InfoCircleFilled");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/LeftOutlined":
/*!*************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/LeftOutlined" ***!
  \*************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/LeftOutlined");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/LoadingOutlined":
/*!****************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/LoadingOutlined" ***!
  \****************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/LoadingOutlined");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/MinusSquareOutlined":
/*!********************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/MinusSquareOutlined" ***!
  \********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/MinusSquareOutlined");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/PaperClipOutlined":
/*!******************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/PaperClipOutlined" ***!
  \******************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/PaperClipOutlined");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/PictureTwoTone":
/*!***************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/PictureTwoTone" ***!
  \***************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/PictureTwoTone");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/PlusOutlined":
/*!*************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/PlusOutlined" ***!
  \*************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/PlusOutlined");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/PlusSquareOutlined":
/*!*******************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/PlusSquareOutlined" ***!
  \*******************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/PlusSquareOutlined");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/QuestionCircleOutlined":
/*!***********************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/QuestionCircleOutlined" ***!
  \***********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/QuestionCircleOutlined");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/ReloadOutlined":
/*!***************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/ReloadOutlined" ***!
  \***************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/ReloadOutlined");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/RightOutlined":
/*!**************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/RightOutlined" ***!
  \**************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/RightOutlined");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/RotateLeftOutlined":
/*!*******************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/RotateLeftOutlined" ***!
  \*******************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/RotateLeftOutlined");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/RotateRightOutlined":
/*!********************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/RotateRightOutlined" ***!
  \********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/RotateRightOutlined");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/SearchOutlined":
/*!***************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/SearchOutlined" ***!
  \***************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/SearchOutlined");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/StarFilled":
/*!***********************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/StarFilled" ***!
  \***********************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/StarFilled");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/SwapOutlined":
/*!*************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/SwapOutlined" ***!
  \*************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/SwapOutlined");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/SwapRightOutlined":
/*!******************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/SwapRightOutlined" ***!
  \******************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/SwapRightOutlined");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/UpOutlined":
/*!***********************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/UpOutlined" ***!
  \***********************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/UpOutlined");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/VerticalAlignTopOutlined":
/*!*************************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/VerticalAlignTopOutlined" ***!
  \*************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/VerticalAlignTopOutlined");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/WarningFilled":
/*!**************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/WarningFilled" ***!
  \**************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/WarningFilled");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/ZoomInOutlined":
/*!***************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/ZoomInOutlined" ***!
  \***************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/ZoomInOutlined");

/***/ }),

/***/ "@ant-design/icons-svg/lib/asn/ZoomOutOutlined":
/*!****************************************************************!*\
  !*** external "@ant-design/icons-svg/lib/asn/ZoomOutOutlined" ***!
  \****************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons-svg/lib/asn/ZoomOutOutlined");

/***/ }),

/***/ "@ant-design/react-slick":
/*!******************************************!*\
  !*** external "@ant-design/react-slick" ***!
  \******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/react-slick");

/***/ }),

/***/ "@rc-component/color-picker":
/*!*********************************************!*\
  !*** external "@rc-component/color-picker" ***!
  \*********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@rc-component/color-picker");

/***/ }),

/***/ "@rc-component/mutate-observer":
/*!************************************************!*\
  !*** external "@rc-component/mutate-observer" ***!
  \************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@rc-component/mutate-observer");

/***/ }),

/***/ "@rc-component/qrcode":
/*!***************************************!*\
  !*** external "@rc-component/qrcode" ***!
  \***************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@rc-component/qrcode");

/***/ }),

/***/ "@rc-component/tour":
/*!*************************************!*\
  !*** external "@rc-component/tour" ***!
  \*************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@rc-component/tour");

/***/ }),

/***/ "classnames":
/*!*****************************!*\
  !*** external "classnames" ***!
  \*****************************/
/***/ ((module) => {

"use strict";
module.exports = require("classnames");

/***/ }),

/***/ "copy-to-clipboard":
/*!************************************!*\
  !*** external "copy-to-clipboard" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("copy-to-clipboard");

/***/ }),

/***/ "ethers":
/*!*************************!*\
  !*** external "ethers" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = import("ethers");;

/***/ }),

/***/ "next/dist/compiled/next-server/pages.runtime.dev.js":
/*!**********************************************************************!*\
  !*** external "next/dist/compiled/next-server/pages.runtime.dev.js" ***!
  \**********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/pages.runtime.dev.js");

/***/ }),

/***/ "path":
/*!***********************!*\
  !*** external "path" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ "rc-cascader":
/*!******************************!*\
  !*** external "rc-cascader" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-cascader");

/***/ }),

/***/ "rc-checkbox":
/*!******************************!*\
  !*** external "rc-checkbox" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-checkbox");

/***/ }),

/***/ "rc-collapse":
/*!******************************!*\
  !*** external "rc-collapse" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-collapse");

/***/ }),

/***/ "rc-dialog":
/*!****************************!*\
  !*** external "rc-dialog" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-dialog");

/***/ }),

/***/ "rc-drawer":
/*!****************************!*\
  !*** external "rc-drawer" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-drawer");

/***/ }),

/***/ "rc-dropdown":
/*!******************************!*\
  !*** external "rc-dropdown" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-dropdown");

/***/ }),

/***/ "rc-field-form":
/*!********************************!*\
  !*** external "rc-field-form" ***!
  \********************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-field-form");

/***/ }),

/***/ "rc-image":
/*!***************************!*\
  !*** external "rc-image" ***!
  \***************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-image");

/***/ }),

/***/ "rc-input":
/*!***************************!*\
  !*** external "rc-input" ***!
  \***************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-input");

/***/ }),

/***/ "rc-input-number":
/*!**********************************!*\
  !*** external "rc-input-number" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-input-number");

/***/ }),

/***/ "rc-input/lib/utils/commonUtils":
/*!*************************************************!*\
  !*** external "rc-input/lib/utils/commonUtils" ***!
  \*************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-input/lib/utils/commonUtils");

/***/ }),

/***/ "rc-mentions":
/*!******************************!*\
  !*** external "rc-mentions" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-mentions");

/***/ }),

/***/ "rc-menu":
/*!**************************!*\
  !*** external "rc-menu" ***!
  \**************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-menu");

/***/ }),

/***/ "rc-motion":
/*!****************************!*\
  !*** external "rc-motion" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-motion");

/***/ }),

/***/ "rc-notification":
/*!**********************************!*\
  !*** external "rc-notification" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-notification");

/***/ }),

/***/ "rc-pagination":
/*!********************************!*\
  !*** external "rc-pagination" ***!
  \********************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-pagination");

/***/ }),

/***/ "rc-pagination/lib/locale/en_US":
/*!*************************************************!*\
  !*** external "rc-pagination/lib/locale/en_US" ***!
  \*************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-pagination/lib/locale/en_US");

/***/ }),

/***/ "rc-picker":
/*!****************************!*\
  !*** external "rc-picker" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-picker");

/***/ }),

/***/ "rc-picker/lib/generate/dayjs":
/*!***********************************************!*\
  !*** external "rc-picker/lib/generate/dayjs" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-picker/lib/generate/dayjs");

/***/ }),

/***/ "rc-picker/lib/locale/en_US":
/*!*********************************************!*\
  !*** external "rc-picker/lib/locale/en_US" ***!
  \*********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-picker/lib/locale/en_US");

/***/ }),

/***/ "rc-progress":
/*!******************************!*\
  !*** external "rc-progress" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-progress");

/***/ }),

/***/ "rc-rate":
/*!**************************!*\
  !*** external "rc-rate" ***!
  \**************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-rate");

/***/ }),

/***/ "rc-resize-observer":
/*!*************************************!*\
  !*** external "rc-resize-observer" ***!
  \*************************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-resize-observer");

/***/ }),

/***/ "rc-segmented":
/*!*******************************!*\
  !*** external "rc-segmented" ***!
  \*******************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-segmented");

/***/ }),

/***/ "rc-select":
/*!****************************!*\
  !*** external "rc-select" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-select");

/***/ }),

/***/ "rc-slider":
/*!****************************!*\
  !*** external "rc-slider" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-slider");

/***/ }),

/***/ "rc-steps":
/*!***************************!*\
  !*** external "rc-steps" ***!
  \***************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-steps");

/***/ }),

/***/ "rc-switch":
/*!****************************!*\
  !*** external "rc-switch" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-switch");

/***/ }),

/***/ "rc-table":
/*!***************************!*\
  !*** external "rc-table" ***!
  \***************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-table");

/***/ }),

/***/ "rc-table/lib/hooks/useColumns":
/*!************************************************!*\
  !*** external "rc-table/lib/hooks/useColumns" ***!
  \************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-table/lib/hooks/useColumns");

/***/ }),

/***/ "rc-tabs":
/*!**************************!*\
  !*** external "rc-tabs" ***!
  \**************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-tabs");

/***/ }),

/***/ "rc-textarea":
/*!******************************!*\
  !*** external "rc-textarea" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-textarea");

/***/ }),

/***/ "rc-tooltip":
/*!*****************************!*\
  !*** external "rc-tooltip" ***!
  \*****************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-tooltip");

/***/ }),

/***/ "rc-tree":
/*!**************************!*\
  !*** external "rc-tree" ***!
  \**************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-tree");

/***/ }),

/***/ "rc-tree-select":
/*!*********************************!*\
  !*** external "rc-tree-select" ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-tree-select");

/***/ }),

/***/ "rc-tree/lib/util":
/*!***********************************!*\
  !*** external "rc-tree/lib/util" ***!
  \***********************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-tree/lib/util");

/***/ }),

/***/ "rc-tree/lib/utils/conductUtil":
/*!************************************************!*\
  !*** external "rc-tree/lib/utils/conductUtil" ***!
  \************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-tree/lib/utils/conductUtil");

/***/ }),

/***/ "rc-tree/lib/utils/treeUtil":
/*!*********************************************!*\
  !*** external "rc-tree/lib/utils/treeUtil" ***!
  \*********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-tree/lib/utils/treeUtil");

/***/ }),

/***/ "rc-upload":
/*!****************************!*\
  !*** external "rc-upload" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-upload");

/***/ }),

/***/ "rc-util":
/*!**************************!*\
  !*** external "rc-util" ***!
  \**************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-util");

/***/ }),

/***/ "rc-util/lib/Children/toArray":
/*!***********************************************!*\
  !*** external "rc-util/lib/Children/toArray" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-util/lib/Children/toArray");

/***/ }),

/***/ "rc-util/lib/Dom/canUseDom":
/*!********************************************!*\
  !*** external "rc-util/lib/Dom/canUseDom" ***!
  \********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-util/lib/Dom/canUseDom");

/***/ }),

/***/ "rc-util/lib/Dom/dynamicCSS":
/*!*********************************************!*\
  !*** external "rc-util/lib/Dom/dynamicCSS" ***!
  \*********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-util/lib/Dom/dynamicCSS");

/***/ }),

/***/ "rc-util/lib/Dom/findDOMNode":
/*!**********************************************!*\
  !*** external "rc-util/lib/Dom/findDOMNode" ***!
  \**********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-util/lib/Dom/findDOMNode");

/***/ }),

/***/ "rc-util/lib/Dom/isVisible":
/*!********************************************!*\
  !*** external "rc-util/lib/Dom/isVisible" ***!
  \********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-util/lib/Dom/isVisible");

/***/ }),

/***/ "rc-util/lib/Dom/shadow":
/*!*****************************************!*\
  !*** external "rc-util/lib/Dom/shadow" ***!
  \*****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-util/lib/Dom/shadow");

/***/ }),

/***/ "rc-util/lib/Dom/styleChecker":
/*!***********************************************!*\
  !*** external "rc-util/lib/Dom/styleChecker" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-util/lib/Dom/styleChecker");

/***/ }),

/***/ "rc-util/lib/KeyCode":
/*!**************************************!*\
  !*** external "rc-util/lib/KeyCode" ***!
  \**************************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-util/lib/KeyCode");

/***/ }),

/***/ "rc-util/lib/React/render":
/*!*******************************************!*\
  !*** external "rc-util/lib/React/render" ***!
  \*******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-util/lib/React/render");

/***/ }),

/***/ "rc-util/lib/hooks/useEvent":
/*!*********************************************!*\
  !*** external "rc-util/lib/hooks/useEvent" ***!
  \*********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-util/lib/hooks/useEvent");

/***/ }),

/***/ "rc-util/lib/hooks/useId":
/*!******************************************!*\
  !*** external "rc-util/lib/hooks/useId" ***!
  \******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-util/lib/hooks/useId");

/***/ }),

/***/ "rc-util/lib/hooks/useLayoutEffect":
/*!****************************************************!*\
  !*** external "rc-util/lib/hooks/useLayoutEffect" ***!
  \****************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-util/lib/hooks/useLayoutEffect");

/***/ }),

/***/ "rc-util/lib/hooks/useMemo":
/*!********************************************!*\
  !*** external "rc-util/lib/hooks/useMemo" ***!
  \********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-util/lib/hooks/useMemo");

/***/ }),

/***/ "rc-util/lib/hooks/useMergedState":
/*!***************************************************!*\
  !*** external "rc-util/lib/hooks/useMergedState" ***!
  \***************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-util/lib/hooks/useMergedState");

/***/ }),

/***/ "rc-util/lib/hooks/useState":
/*!*********************************************!*\
  !*** external "rc-util/lib/hooks/useState" ***!
  \*********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-util/lib/hooks/useState");

/***/ }),

/***/ "rc-util/lib/isEqual":
/*!**************************************!*\
  !*** external "rc-util/lib/isEqual" ***!
  \**************************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-util/lib/isEqual");

/***/ }),

/***/ "rc-util/lib/omit":
/*!***********************************!*\
  !*** external "rc-util/lib/omit" ***!
  \***********************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-util/lib/omit");

/***/ }),

/***/ "rc-util/lib/pickAttrs":
/*!****************************************!*\
  !*** external "rc-util/lib/pickAttrs" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-util/lib/pickAttrs");

/***/ }),

/***/ "rc-util/lib/raf":
/*!**********************************!*\
  !*** external "rc-util/lib/raf" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-util/lib/raf");

/***/ }),

/***/ "rc-util/lib/ref":
/*!**********************************!*\
  !*** external "rc-util/lib/ref" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-util/lib/ref");

/***/ }),

/***/ "rc-util/lib/utils/set":
/*!****************************************!*\
  !*** external "rc-util/lib/utils/set" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-util/lib/utils/set");

/***/ }),

/***/ "rc-util/lib/warning":
/*!**************************************!*\
  !*** external "rc-util/lib/warning" ***!
  \**************************************/
/***/ ((module) => {

"use strict";
module.exports = require("rc-util/lib/warning");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react-dom":
/*!****************************!*\
  !*** external "react-dom" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "react/jsx-runtime":
/*!************************************!*\
  !*** external "react/jsx-runtime" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ "scroll-into-view-if-needed":
/*!*********************************************!*\
  !*** external "scroll-into-view-if-needed" ***!
  \*********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("scroll-into-view-if-needed");

/***/ }),

/***/ "throttle-debounce":
/*!************************************!*\
  !*** external "throttle-debounce" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("throttle-debounce");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/@swc","vendor-chunks/antd","vendor-chunks/@ant-design","vendor-chunks/@babel"], () => (__webpack_exec__("(pages-dir-node)/./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES&page=%2F&preferredRegion=&absolutePagePath=.%2Fpages%5Cindex.js&absoluteAppPath=private-next-pages%2F_app&absoluteDocumentPath=private-next-pages%2F_document&middlewareConfigBase64=e30%3D!")));
module.exports = __webpack_exports__;

})();
import Page from './home/index'
export default function Home() {
  
  return (
    <>
    <Page/>
    </>
  );
}
